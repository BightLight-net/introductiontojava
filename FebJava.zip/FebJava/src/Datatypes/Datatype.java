/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datatypes;

/**
 *
 * @author Kunlex
 */
public class Datatype {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // primitive datatype
        //object reference  data type
        
        byte num1 = 100;
        short num2 = 1000;
        int num3 = 3000000;
        long num4= 666666666;
        float num5 =  123.4f;
        boolean num6 = true;
        char num7 = 'C';
        
    }
    
}
