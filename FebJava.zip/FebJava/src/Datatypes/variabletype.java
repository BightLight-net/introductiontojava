/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datatypes;

/**
 *
 * @author Kunlex
 */
public class variabletype {
    
    public void studAge(){
    int age = 0;
    age = age +7;
    System.out.println("Student age is : " + age);
    
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // local variable
        //instance variable
        //class/static variable
        
        variabletype  obj = new variabletype(); 
        obj.studAge();
        //obj.age;
        
        
    }
    
}
