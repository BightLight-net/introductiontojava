
package LoopAndArray;


public class whileloop {

    
    public static void main(String[] args) {
        // TODO code application logic here
        
        
        int age = 2;
        
        do{
        
           System.out.println("At age " + age+ " you can still take immunizarion");
           
        age++;
        }while(age < 10);
        
        
    }
    
}
