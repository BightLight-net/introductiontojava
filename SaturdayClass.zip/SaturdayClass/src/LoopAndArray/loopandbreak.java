
package LoopAndArray;


public class loopandbreak {

    
    public static void main(String[] args) {
        int passmark = 12;
        boolean passed = false;
        
        int[] scores = {4,6,2,8,12,35,9};
        
       for(int unitScore: scores){ 
           System.out.print(unitScore);
            if(unitScore >= 12){
            passed = true;
            break;
        }
       }
       System.out.print("At Least One Passed?" +passed);
        
        
        
        
    }
    
}
