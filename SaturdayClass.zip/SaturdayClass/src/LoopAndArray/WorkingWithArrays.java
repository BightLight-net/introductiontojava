
package LoopAndArray;

import java.util.Scanner;


public class WorkingWithArrays {

  
    public static void main(String[] args) {
        
        int num = 5;
        
        int[] num1 = {5,6,6};
        
        
        Scanner scan = new Scanner(System.in);
    
       
        String[]  Names  = new String[5];
        
       
         Names[0] = "Adamu";
       Names[1] = "Tony";
        Names[2] = "Ali";
        Names[3] = "Lakes";
        Names[4] = "Brown";
        
        
        System.out.println(Names[0]);
        System.out.println(Names.length);
        
        // Looping An Array
        //Enhanced for loop
        
        for(String clap : Names ){
            System.out.println(clap);
        
        }
        
        
//        for(String call: Names ){
//            if(call.charAt(0) == 'A'){
//            System.out.println(call);
//            }
//            
//        
//        
//        }
        
       /* 
        for(intialization; condition; increement/decreement){
        // code here
        }
        */
        
//        for(int a =0; a<Names.length; a++){
//        System.out.print("Please the "+(a)+ " element of the array: ");
//        Names[a] = scan.next();
//        }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
    
}
