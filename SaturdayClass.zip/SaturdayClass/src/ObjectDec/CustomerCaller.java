
package ObjectDec;


public class CustomerCaller {

    
    public static void main(String[] args) {
       
        Customer customer01 = new Customer();
	Customer customer02 = new Customer();

	customer01.age = 40;
	customer02.name = "Duke"; 

	customer01.displayCustomer();
	customer02.displayCustomer();

        
        
        
    }
    
}
