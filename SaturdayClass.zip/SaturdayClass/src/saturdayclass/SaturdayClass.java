
package saturdayclass;


public class SaturdayClass {

    
    public static void main(String[] args) {
        byte rabiaah  = 22;
        short yakub = 3276;
        int num3 = 45678;
        long num4 = 2334456;
        float num5 = 55.666f;
        double num6 = 6566.8887;
        boolean truth = true;
        char value = 't';
        
      String elvis = "WE are in java class";
        
        
       
        
        
        
    }
    
    
    
}
