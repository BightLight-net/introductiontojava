
package Projects;

import java.util.Scanner;

public class VowelDectector {

  
    public static void main(String[] args) {
      Scanner scan = new Scanner(System.in);
      System.out.println(" Enter the charcter: ");
      char ch = scan.next().charAt(0);
      boolean isVowel = false;
      
      switch(ch){
          case 'a':
          case 'e':
          case 'i':
          case 'o':
          case 'u':
          case 'A':
          case 'E':
          case 'I':    
          case 'O':
          case 'U':   isVowel = true;       
      }
      if(isVowel == true){
      System.out.println(ch+ " is a Vowel");
      }else{
      System.out.println(ch+ " is a Consonant");
      }
        
        
    }
    
}
