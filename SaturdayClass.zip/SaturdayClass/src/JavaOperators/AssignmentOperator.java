
package JavaOperators;

public class AssignmentOperator {

  
    public static void main(String[] args) {
        int num1 = 10;
        int num2 = 20;
        
        num2 = num1 ;
        System.out.println("=output: "+num2); //10
        
        num2 += num1 ;  // meaning num2 = num2 + num1
        System.out.println("+=output: "+num2); //20
        
        num2 -= num1 ;
        System.out.println("-=output: "+num2); //10
        
        num2 *= num1 ;
        System.out.println("*=output: "+num2); //100
        
        num2 /= num1 ;
        System.out.println("/=output: "+num2); //10
        
        num2 %= num1 ;    //0
        System.out.println("%=output: "+num2);
        
        
        
        
        
        
    }
    
}
