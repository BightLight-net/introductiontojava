/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JavaOperators;

/**
 *
 * @author HP
 */
public class AutoOpeator {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int num1 = 100;
        int num2 = 200;
        
        num1++;
        num2--;
        
        System.out.println("num1++ is: "+num1);  //101
        System.out.println("num2++ is: "+num2);// 199
        
        
        
        
    }
    
}
