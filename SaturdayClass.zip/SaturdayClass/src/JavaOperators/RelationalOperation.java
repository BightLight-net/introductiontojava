
package JavaOperators;

public class RelationalOperation {

    
    public static void main(String[] args) {
        int num1 = 10;
        int num2 = 50;
        
     if(num1 == num2){
                
           System.out.println("num1 and num2 are equal");
     }else{
         System.out.println("num1 and num2 are  not equal");
                        
                        }
     
     if(num1 != num2){
     System.out.print("num1 and num2 are not  equal");
     
     }else{ System.out.print("num1 and num2 are  equal");}
        
     
     if (num1 >= num2){
      System.out.print("num1 is greater than or equal to num2");
     }else{
      System.out.print("num1 is less than num2");
     }
     
     
    }
    
}
