
package ConditionStatment;

import java.util.Scanner;

public class inputfromuser {

    
    
    
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        System.out.print("Please enter first number");
        int firstnum = scan.nextInt();
        
        System.out.print("Please enter second number");
        int secondnum = scan.nextInt();
        
        int answer = firstnum + secondnum;
        
        System.out.print(answer);
                
                
                
                
                
    }
    
}
