
package ConditionStatment;

import java.util.Scanner;
public class tenseUnit {

 
    public static void main(String[] args) {
        Scanner elvis = new Scanner(System.in);
         System.out.println("Enter a Number for Elvis");
        int num = elvis.nextInt();
        
        if(num < 100 && num >=1){
            if(num >= 0 && num < 9)  {
            System.out.println("Its a digit number");
            }
        System.out.println("Its a two digit number");
        }else if ( num >= 100 && num < 1000){
            System.out.println("Its a three digit number");
        }else if ( num >= 1000 && num < 9999){
            System.out.println("Its a four digit number");
        }else if(num >=10000 && num<99999){
         System.out.println("Its a five digit number");
        }else {
        System.out.println("number is not between 1 & 99999");
        }
    }
    
}
