
package ConditionStatment;


public class usingswitch {

   
    public static void main(String[] args) {
        
        char time = 'a';
        
        switch(time){
        case 'a' : 
        System.out.println("The time is 1 pm");
            break;
            
        case 'b' : 
        System.out.println("The time is 2 pm"); 
            break;
            
         case 3 : 
        System.out.println("The time is 3 pm");
             break;
             
        case 4 : 
        System.out.println("The time is 4 pm");
            break;
            
        default:  System.out.println("its from 5 upwards");   
        
    
    }
        
        
    }
    
}
