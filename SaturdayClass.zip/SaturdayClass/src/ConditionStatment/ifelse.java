
package ConditionStatment;

public class ifelse {

    
    public static void main(String[] args) {
       int score = 70;
       
       if (score > 60){
       System.out.println("You Passed!");
       }else {
       System.out.println("You didnt, You understand Na!");
       }
       
    }
    
}
