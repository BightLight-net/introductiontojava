
package variables;

public class InstanceVariable {
    String myInstanceVar = "intance variable";

   
    public static void main(String[] args) {
        InstanceVariable job1 = new InstanceVariable();
        InstanceVariable job2 = new InstanceVariable();
        InstanceVariable job3 = new InstanceVariable();
        
        System.out.println(job1.myInstanceVar);
        System.out.println(job2.myInstanceVar);
        System.out.println(job3.myInstanceVar);
        
        job2.myInstanceVar = "Changed Text"; 
        job1.myInstanceVar = "This is For Job1";
        
        System.out.println(job1.myInstanceVar);
        System.out.println(job2.myInstanceVar);
        System.out.println(job3.myInstanceVar);
        
    }
    
}
