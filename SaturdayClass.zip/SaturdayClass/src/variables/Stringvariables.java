
package variables;


public class Stringvariables {

   
    public static void main(String[] args) {
        
        String greet1 = "Hello";
        String greet2 = "World";
        
        String name = "Bob";
String msg;
int num = 3; 

        
        System.out.println(greet1 +" " + greet2 +" "+ "!" );
        
        int c = (25 - 5 * 4) /( 2 - 10 + 4);
        System.out.println(c);
        
        
        msg = name + " wrote " + 2+1 + " Java programs.";
        System.out.println(msg );
        
      String  msg1 = "Bob wrote "+ (2+1) + " Java programs.";
         System.out.println(msg );
      String  msg2 = name + " wrote " + 3 + " Java programs.";
         System.out.println(msg2 );
       // msg = name + " wrote " + num " Java programs.";





        
    }
    
}
