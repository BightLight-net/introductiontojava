
package variables;

public class StaticVariable {
    
    public static String myClassVar = "class or static variables";

    public static void main(String[] args) {
        
        StaticVariable job1 = new StaticVariable();
        StaticVariable job2 = new StaticVariable();
        StaticVariable job3 = new StaticVariable();
        
        //All three will display "class or static variable"
      System.out.println(job1.myClassVar);
      System.out.println(job2.myClassVar);
      System.out.println(job3.myClassVar);
      
      //changing the value of static variable using job2
      job2.myClassVar = "Changed Text";
      job1.myClassVar = "Changed Text Just now";
      
      //All three will display "Changed Text"
      System.out.println(job1.myClassVar);
      System.out.println(job2.myClassVar);
      System.out.println(job3.myClassVar);
      System.out.println(StaticVariable.myClassVar);
      
      
    
        
        
    }
    
}
