
package variables;

/**
 *
 * @author HP
 */
public class MoreOnVariable {
    // Instance Variable
    String myInstanceVar = "This variable is an instance variable";
    
    public void myMethod(){
    // local 
    String myLocalVar = "This varaible is inside a method";
    System.out.println(myLocalVar);

}

    
    public static void main(String[] args) {
        /*
        Three types of variable
        local variable
        instance varable
        static variable
        
        Two categories of variables
        primitive variable
        object refrence variable
        
        */       
        // We are creating an object reference variable.......
        //Classname theobject = new Classname();
        MoreOnVariable obj = new MoreOnVariable();
       obj.myMethod();
       System.out.print(obj.myInstanceVar);
        
        
        
        
    }
    
}
