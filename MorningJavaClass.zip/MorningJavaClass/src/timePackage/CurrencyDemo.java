
package timePackage;

/**
 *
 * @Kunle Java
 */
import java.util.Currency;
import java.util.Locale;

public class CurrencyDemo {

    public static void main(String[] args) {
        // prograam to know the currency of a country
       Currency c1 = Currency.getInstance(Locale.ITALY);
       System.out.println("The currency in ITALY is " +c1);
       
//       Currency c2 = Currency.getInstance(Locale.CHINESE);
//       System.out.println("The currency in ITALY id" +c2);
       
       
       Currency c3 = Currency.getInstance(Locale.GERMANY);
       System.out.println("The currency in ITALY is " +c3);
       
       
       Currency c4 = Currency.getInstance(Locale.JAPAN);
       System.out.println("The currency in ITALY is " +c4);
       
       
       Currency c5 = Currency.getInstance(Locale.CHINA);
       System.out.println("The currency in ITALY is " +c5);
       
//       
//       Currency c6 = Currency.getInstance(Locale.FRENCH);
//       System.out.println("The currency in ITALY id" +c6);
       
        
        
        
        
    }
    
}
