
package timePackage;

/**
 *
 * @Kunle Java
 */
import java.util.Calendar;
import java.time.chrono.HijrahDate;
import java.time.LocalDate;
import java.time.temporal.ChronoField;
import java.time.temporal.TemporalAdjusters;

public class Greet {

  
    public static void main(String[] args) {
        // A program that will Greet You and tell the date
        Calendar cal = Calendar.getInstance();
        int hour = cal.get(Calendar.HOUR_OF_DAY);
        
        int minute = cal.get(Calendar.MINUTE);
        
        int seconds = cal.get(Calendar.SECOND);
        
        int month = cal.get(Calendar.MONTH);
        
        int day = cal.get(Calendar.DAY_OF_WEEK);
        
        if (hour < 12){
        System.out.println("Good morning");
        }
        
        else if (hour >= 12 && hour < 17){
        System.out.println("Good Aternoon");
        }
        else{
        System.out.println("Good evening");
        }
        
        if(minute !=0) {
            System.out.print("The Time is "+ minute +" ");
        System.out.print((minute !=1) ? "minutes ": "minute");
             System.out.print(" after ");
              
        }
        if(hour <=12){
        System.out.print(hour + "AM");
        }
        else{
        System.out.print(hour-12 + "PM");
        }
        System.out.print(".  Today is ");
        switch(day){
            case 1:System.out.print("Sunday");
                break;
                case 2: System.out.print("Monday");
                break;
                    case 3: System.out.print("Tuesday");
                break;
                        case 4: System.out.print("Wednesday");
                break;
                            case 5: System.out.print("Thurday");
                break;
                                case 6: System.out.print("Friday");
                break;
                                default: System.out.print("Saturday");
                                    break;
            
       
        }      
        
    }
    
}
