
package Condition;

import javax.swing.JOptionPane;
public class ConditionalStatement {
    public static void main (String[] args){
    
        String Display = JOptionPane.showInputDialog(null, "How old are you");
        
        int age = Integer.parseInt(Display);
        
        if(age <18){
            JOptionPane.showMessageDialog(null, "you are too young to vote");
        
        }else{
        
        
        }
    
        
        
    
    }
    
}
