
package morearray;

/**
 *
 * @kunle java
 */
public class multidimentionalArray {

    public static void main(String[] args) {
        // TODO code application logic here
        int[][] scores = new int [6][6];
        
        scores[0][0] = 34;
        scores[0][1] = 56;
        scores[0][2] = 56;
        scores[0][3] = 34;
        scores[0][4] = 24;
        scores[0][5] = 56;
        
        scores[1][0] = 5;
        scores[1][1] = 4;
        scores[1][2] = 56;
        scores[1][3] = 90;
        scores[1][4] = 81;
        scores[1][5] = 34;
        
        scores[2][0] = 5;
        scores[2][1] = 4;
        scores[2][2] = 56;
        scores[2][3] = 90;
        scores[2][4] = 81;
        scores[2][5] = 34;
        
        scores[3][0] = 5;
        scores[3][1] = 4;
        scores[3][2] = 56;
        scores[3][3] = 90;
        scores[3][4] = 81;
        scores[3][5] = 34;
        
        scores[4][0] = 5;
        scores[4][1] = 4;
        scores[4][2] = 56;
        scores[4][3] = 90;
        scores[4][4] = 81;
        scores[4][5] = 34;
        
        scores[5][0] = 5;
        scores[5][1] = 4;
        scores[5][2] = 56;
        scores[5][3] = 90;
        scores[5][4] = 81;
        scores[5][5] = 34;
        
        int row = scores.length;
        int column = scores.length;
    
        
        for (int a=0; a<row; a++){
            for(int b=0 ; b<column; b++){
            System.out.print(scores[a][b]+ "\t");
            
            }
        System.out.println(" ");
        }
        
        
        } 
        
        
        
        
        
        
    }
    

