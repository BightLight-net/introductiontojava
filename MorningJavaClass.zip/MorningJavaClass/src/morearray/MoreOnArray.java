
package morearray;

/**
 *
 * @kunle java
 */
public class MoreOnArray {
    
    public static void main(String[] args) {
      int[] ages = {12,67,80,67,53,63}; //arrayname is ages, data-type is int
      System.out.println("The element at position 1 is" + ages[0]);
      System.out.println("The element at position 1 is" + ages[1]);
      System.out.println("The element at position 1 is" + ages[2]);
      System.out.println("The number of elements in the array is " + ages.length);
      
      for(int a=0; a<ages.length; a++){
      System.out.println("The element at position "+a+" is "+ ages[a]);
      
      }
      
      //Enhanced for loop
      for(int c:ages){
          System.out.println("using the enchanced for loop" + c);
      
      }
      
        
        
    }
    
}
