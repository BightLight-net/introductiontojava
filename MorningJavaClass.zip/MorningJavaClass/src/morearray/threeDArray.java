/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package morearray;

/**
 *
 * @author HP
 */
public class threeDArray {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        int arr[][][] = new int [4][5][6];
        arr [0][0][0]= 45;
        arr [0][0][1]= 56;
        arr [0][1][1]= 50;
        arr [1][0][0]= 90;
        
        int arra [][][] = {
            {
                {12,45,67},{34,67,86}
            },
            {{3,5,7},{65,8,54}
            },
            {{4,2,4},{6,3,9}
            }     
        };
        
        for(int a=0; a<arra.length; a++){
            for(int b=0; b<arra[a].length; b++ ){
                for(int c=0; c<arra[a][b].length; c++){
                    System.out.print(arra[a][b][c]+", \t");
                }
                System.out.println();
            }
            System.out.println();
        }
        
        
    }
    
}
