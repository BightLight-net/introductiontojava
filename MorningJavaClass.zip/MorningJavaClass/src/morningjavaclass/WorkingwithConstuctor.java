
package morningjavaclass;

public class WorkingwithConstuctor {

    public static void main(String[] args) {
        
        ContructorPage a =  new ContructorPage(500000,15,10);
        ContructorPage b = new ContructorPage(2);
        ContructorPage c = new ContructorPage( "ibadan",3);
        
//        a.display();
//        b.display();
//        c.display();
        
        
        
        
    }
    
}
