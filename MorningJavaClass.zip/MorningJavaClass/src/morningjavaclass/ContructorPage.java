
package morningjavaclass;

/**
 *
 * @author HP
 */
public class ContructorPage {
    int salary;
    int workers;
    int workinghrs;
    String location = "abuja";
    
    public ContructorPage(int s,int w,int whrs){
    System.out.println("This is the first Contructor");
   // location = "Jos";
    
    s= salary;
    w= workers;
    whrs= workinghrs;
    secure();
    
    }
    
    public ContructorPage( int a){
    System.out.println("This is the "+a+"Constructor");
    location = "lagos";
    }
    public ContructorPage(String place,int b){
    System.out.println("Mr "+place+"This is the "+b+"Constructor");
    location = "enugu";
    }
    
    public void display(){
    System.out.println(location);
    }
    
    public void secure(){
     System.out.print("I am securing your class");
    
    }
    
    
    
    
}
