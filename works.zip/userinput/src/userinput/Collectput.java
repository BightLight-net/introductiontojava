

package userinput;



import javax.swing.JOptionPane;
public class Collectput {

    
    public static void main(String[] args) {
        // TODO code application logic here
    
        
    String firstname;
    firstname = JOptionPane.showInputDialog("firstname","Please enter your firstname");
   
    String surname;
    surname = JOptionPane.showInputDialog("surname","Please enter your surname");
    
  String  fullname = "Your name are: "+ " " + firstname + "  "+ surname;
  
  JOptionPane.showMessageDialog(null, fullname,"Name",JOptionPane.INFORMATION_MESSAGE);
    System.exit(0);
    
  
    
   
    }
    
}
