/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package twopages;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import SceneB.SceneB;
import javafx.geometry.Rectangle2D;
import javafx.stage.Modality;
import javafx.stage.Screen;
import static javax.accessibility.AccessibleState.MODAL;
/**
 *
 * @author HP
 */
public class TwoPagesController implements Initializable {
    
   
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void openScene(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("/SceneB/SceneB.fxml"));
        Scene scene = new Scene(root);
        Stage stage = new Stage(StageStyle.DECORATED);
        stage.setTitle("Scene Two");
        stage.getIcons().add(new Image("/twopages/1..jpg"));
        stage.setScene(scene);
        /*stage.initModality(Modality.APPLICATION_MODAL);
        Screen screen = Screen.getPrimary();
        Rectangle2D bound = screen.getVisualBounds();
        stage.setX(bound.getMinX());
        stage.setY(bound.getMinY());
        stage.setWidth(bound.getWidth());
        stage.setWidth(bound.getHeight());
        stage.setMaximized(true);*/
        stage.show();
        
        
        
        
        
        
        
    }
    
}
