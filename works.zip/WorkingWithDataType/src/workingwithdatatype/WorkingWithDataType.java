
package workingwithdatatype;


public class WorkingWithDataType {

    
    public static void main(String[] args) {
//        byte num = 127;
//        short num1 = 30000;
//        int num2 = 450384;
//        long num3 = 4585854;
//        float num4 = 34.56f;
//        double num5 = 4534.5566;
//        boolean num6 = true;
//        char num7 = 'e';
        PascalTransport Car = new PascalTransport();
        ObjectRefrence Tobi = new  ObjectRefrence();
        Tobi.freefood();
        Car.trans();
        
        
        
        
        
        
    }
    
}
