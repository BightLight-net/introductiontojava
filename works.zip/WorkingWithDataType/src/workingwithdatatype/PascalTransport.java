
package workingwithdatatype;


public class PascalTransport {
   public  void trans(){
    System.out.print("Pascal Transport runs From  Onitha to Owerri");
    
    }
    
    
}
