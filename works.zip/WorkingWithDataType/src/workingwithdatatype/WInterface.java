
package workingwithdatatype;
interface school{

}


public class WInterface {
    
    
}
