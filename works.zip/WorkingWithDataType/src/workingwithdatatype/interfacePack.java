
package workingwithdatatype;

public interface interfacePack {
    
}
