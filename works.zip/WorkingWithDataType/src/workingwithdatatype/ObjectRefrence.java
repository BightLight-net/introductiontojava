

package workingwithdatatype;


public class ObjectRefrence {
    
    public void freefood(){
    System.out.println("Take free food at KFC");
    
    }
    
    
}
