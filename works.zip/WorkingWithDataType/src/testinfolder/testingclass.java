/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testinfolder;

/**
 *
 * @author HP
 */
public class testingclass {
    //the two categories of variable are
    //primitive variable
    //object reference variable
    
    byte paul =34;
    short num1 = 234;
    int num2=3445;
    long num4 = 3456789;
    float num5 =4455555.445f;
    double num6 = 3445555.443333;
    boolean bum7 = true;
    char num8 = 'h';
    
    
    
    
    
    
}
