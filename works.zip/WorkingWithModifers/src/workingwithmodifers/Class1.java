
package workingwithmodifers;


public class Class1 {

    
    public static void main(String[] args) {
       Class2 c1 = new Class2();  // instantiating Class2
        
        System.out.println("default variable "+c1.ManagerName);
        System.out.println("public variable "+c1.occupation);
        //System.out.println("private variable "+c1.gender);
        System.out.println("protected variable "+c1.religion);
        
        Class3.methodClass3();
        
        
    }
    
}
