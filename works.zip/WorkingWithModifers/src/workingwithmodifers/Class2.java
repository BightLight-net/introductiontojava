
package workingwithmodifers;


public class Class2 {
    String ManagerName = "Tobi";
    public String occupation = " Software Developer";
    private String gender = "male";
    protected  String religion = "christian";
    
    
}
