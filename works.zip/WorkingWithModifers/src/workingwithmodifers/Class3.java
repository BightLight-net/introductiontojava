
package workingwithmodifers;


public class Class3 extends Class2{
    
   public static void  methodClass3 (){
Class3 c2  = new Class3(); 
       System.out.println("default variable in class3 "+c2.ManagerName);
        System.out.println("public variable in class3"+c2.occupation);
        //System.out.println("private variable in class3 "+c2.gender);
        System.out.println("protected variable  in class3"+c2.religion);

}
    
    
}
