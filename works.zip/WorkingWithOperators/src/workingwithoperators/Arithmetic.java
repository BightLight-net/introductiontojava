
package workingwithoperators;

=
public class Arithmetic {

    
    public static void main(String[] args) {
//        Assignment =, +=, -=, *=, /= Assign value to a variable
//Arithmetic +, -, *, /, %, ++, -- Add, subtract, multiply, divide, and modulus primitives
//Relational <, <=, >, >=, ==, != Compare primitives
//Logical !, &&, || Apply NOT, AND, and OR logic to primitives
//        
       /* int a =  20;
        int b= 10;
        int c = a-++b;
        System.out.println(b);  // the result will be 11
        System.out.println(c); // the result will be 9
        
            int d =  20;
        int f= 10;
        int g = d-f++;
        System.out.println(g); // the result will be 10
        System.out.println(f); // the result will be 11 */
        
        int a = 100;
        int b = 30;
        int c = a%b;
         
        System.out.println(c);
        
        if(a>b || c>a){
         System.out.println("This will display if a is equal to b ");
         int d = a*b;
         System.out.println(d);
        }; 
          
    }
    
}
