/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package wewewe;

/**
 *
 * @author user
 */
public class saew {

   
    public static void main(String[] args) {
        
         int[]day =  new int[46];
        
         //day[0] = 12;
         ////day[1] = 43;
         //day[2] = 22;
         //day[3] = 44;
         //day[4] = 21;
         //////day[5] = 45;
         //day[6] = 54;
         //day[7] = 23;
         int i;
         for (i=0; i<day.length; i++ ){
         day[i]= i + 1; 
             System.out.print(day[i]);
        
        
    }
    
}
}