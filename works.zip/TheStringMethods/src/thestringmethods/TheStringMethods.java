
package thestringmethods;


public class TheStringMethods {

    
    public static void main(String[] args) {
        System.out.println("Printing out String using double quote"); // first method
    String name ="Oluwalobamise";
    System.out.println("Printing out String using variable name gives "+name); // second method
        
        String state = new String("Lagos");
        System.out.println("Printing a string using new keyword gives" +state);
       
        char[] word = {'h','e','l','l','o'};
        String nw = new String(word);
    System.out.println(nw);
    System.out.println(state.length()); // returns the length of the string
    System.out.println(state.concat(" ").concat(nw)); // concatenate string
    System.out.println(state.charAt(2)); // character at a posiion
    System.out.println(state.contains("o")); // checks if it contains a particular character
    System.out.println(state.toUpperCase()); // prints in upper case
        System.out.println(state.toLowerCase());// prints in Lower case
         System.out.println(state.substring(2));// starts printing at a particular position
         System.out.println(name.substring(2,8)); //starts printing at postiion 2 and stops at position 8
        
        
    }
    
}
