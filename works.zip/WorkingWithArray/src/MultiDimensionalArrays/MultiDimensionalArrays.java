
package MultiDimensionalArrays;

public class MultiDimensionalArrays {

    
    public static void main(String[] args) {
        // TODO code application logic here
        
        int [][] price = new int [6][5];
        
        price[0][0] = 60;
        price[0][1] = 70;
        price[0][2] = 50;
        price[0][3] = 20;
        price[0][4] = 10;
        
        
        price[1][0] = 60;
        price[1][1] = 74;
        price[1][2] = 4;
        price[1][3] = 67;
        price[1][4] = 1433;
        
        price[2][0] = 66;
        price[2][1] = 77;
        price[2][2] = 556;
        price[2][3] = 63;
        price[2][4] = 143;
        
        int rows =6;
        int colums = 5;
        
        int i, j;
        
        for(i=0; i<rows ; i++ ){
            for(j=0; j < colums; j++ ){
        System.out.print(price[i][j] + " ");
            }
            System.out.println(" ");
        } 
                  
    }
    
}
 
 