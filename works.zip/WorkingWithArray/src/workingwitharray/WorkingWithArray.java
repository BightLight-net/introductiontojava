
package workingwitharray;

import java.util.Arrays;
public class WorkingWithArray {

   
    public static void main(String[] args) {
        // TODO code application logic here
        int [] price = {500, 950, 300, 10, 45 };
        String [] cities = {"onistha", "lagos", "london", "ontario","paris" };
        char [] letters = {'w','e','l','c','o','m','e'};
        
        System.out.println(price[2]);
        System.out.println(cities[3]);
        System.out.println(letters[0]);
        
       System.out.println(price.length);
        
       int count = letters.length;
       
       String [] cafteams = new String[4];
       
       cafteams[0]= " burundi ";
       cafteams[1]= " nigeria ";
       cafteams[2]= " guinea ";
       cafteams[3]= " madagasca ";
       
       // Sorting an Array...........
       //To sort an array we need to import the Arrays Class
        
        Arrays.sort(cafteams);
        
        int i;
        for(i=0; i<cafteams.length; i++){
        System.out.println("caf teams in group B are: " + cafteams[i]);
        }
       
        
    }
    
}
