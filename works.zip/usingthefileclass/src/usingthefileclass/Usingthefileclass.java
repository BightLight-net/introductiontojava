
package usingthefileclass;

/**
 *
 * @kunle java
 */

import java.io.File;
import java.io.IOException;

public class Usingthefileclass {

    
    public static void main(String[] args) {
       String filePath = "C:" + File.separator + "myfold" + File.separator + "m6"
               + File.separator + "m2"; 
       String cDrive = "C:";
       File f = new File(filePath);
       File cObj = new File (cDrive);
       
       try{
           if(!f.exists()){
           f.mkdir();
           System.out.println("Folder: "+ f.getPath() +"created successfully");
           
           }
           else {System.out.println("Folder already exist");
           }   
       }
       catch(Exception e){
       e.getMessage();
       }
       try{
       System.out.println("My C drive size is "+cObj.getTotalSpace());
       System.out.println("My C drive has free space of "+cObj.getFreeSpace());
       System.out.println("My C drive size is "+cObj.getUsableSpace());
       }
       catch(Exception e){
       e.getMessage();
       }
       
       
        
        
        
        
        
    }
    
}
