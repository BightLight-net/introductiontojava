
package usingthefileclass;

/**
 *
 * @kunle java
 */
import java.io.*;


public class Foldercreation {

    
    public static void main(String[] args) {
      String folder  = "C:" +File.separator +"Users"+File.separator+"Public"+File.separator+"all";
      File m5 = new File(folder);
      
      try{
          if(!m5.exists()){
              m5.mkdir();
              System.out.print("Folder created successfully");
          
          }
          else{
              System.out.println("Folder already exists");
          
          }
      }catch(Exception e){
          System.out.println("Folder creation failed");
     }
      //String folders = "C:" + File
      
      
      
      }
        
        
        
    }
    

