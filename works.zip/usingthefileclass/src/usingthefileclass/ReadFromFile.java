package usingthefileclass;

/**
 *
 * @kunle java
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import javax.swing.JFileChooser;


public class ReadFromFile {
    public static void main(String[] args)throws FileNotFoundException  {
     JFileChooser j = new JFileChooser();
     
     if (j.showOpenDialog(null) == JFileChooser.APPROVE_OPTION){
     File m = j.getSelectedFile();
     
     Scanner input =  new Scanner(m);
     
     while(input.hasNext()){
     System.out.println(input.nextLine());
     }
     input.close();
        
     }
        
        
        
    }
    
}
