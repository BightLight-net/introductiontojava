
package workingwithmethods;


public class Headteacher {

   
    public static void main(String[] args) {
        // TODO code application logic here
     MathTeacher  coni = new MathTeacher();
     
     coni.mathattendance();
      
      System.out.println(coni.MathSkimOfWork());
        
        
    }   
}

 class MathTeacher{
     String Mathbook = " This is my math text book ";
 
 public String MathSkimOfWork(){
 
 return Mathbook;
 
 }
 
 public void mathattendance(){
 int numOfstudent = 50;
 String gender = "female";
 System.out.print("There are " + numOfstudent+ " " + gender );
 
 
 } 
 
 
 
 
 }
