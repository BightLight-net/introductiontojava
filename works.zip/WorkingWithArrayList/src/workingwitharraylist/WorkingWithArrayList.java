
package workingwitharraylist;

import java.util.ArrayList;
import java.util.Scanner;
public class WorkingWithArrayList {

   
    public static void main(String[] args) {
        // TODO code application logic here
        
        ArrayList  item = new ArrayList();
        Scanner   scan = new Scanner(System.in);
        
//        item.add("Garri");
//        item.add("Spagetti");
//        item.add("tomato");
//        item.add("Epa");
//        item.add("Noodles");
//        item.add(98);

        System.out.print("please enter number of item");
        int num = scan.nextInt();
        
        Scanner   scan1 = new Scanner(System.in);
        for(int i= 0 ; i<num; i++ ){
          System.out.print("please your  items");  
        String items = scan1.next();
        item.add(items);
       
        }
        
        
        // Remove the first item
        //item.remove("Garri");
        
        // Print out the list
        System.out.println("Whole list: " + item);
        
        // Get the item at index position 1
       // System.out.print("Position 1 =" + item.get(1));
        
       
    }
    
}
