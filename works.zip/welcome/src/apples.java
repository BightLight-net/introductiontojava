/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author GOODNESS
 */
public class apples {
    public static void main(String[] args){
    System.out.println("Hello New Horizons");
    
  System.out.print("Hello java");
        String firstname="world";
        String secondname="cup";
        String together=firstname+" "+secondname;
        
         System.out.println("The whole world is in BRAZIL for the " +together);

    
    
    
    }
    
}
