/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package welcome;

/**
 *
 * @author GOODNESS
 */
public class Welcome {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    //    System.out.print("Hello java");
        String firstname="world";
        String secondname="cup";
        String together=firstname+" "+secondname;
        
        System.out.println("The whole world is in BRAZIL for the " +together);
                
        // TODO code application logic here
    }
}
