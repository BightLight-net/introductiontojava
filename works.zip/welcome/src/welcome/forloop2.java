/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package welcome;
import java.util.Scanner;
/**
 *
 * @author GOODNESS
 */
public class forloop2 {
      public   static void main (String []args){
        int ask;
        //int stoppingPoint=40;
        Scanner STOPit=new Scanner (System.in);
        
        
        
       int stoppingPoint;
       System.out.println("how many loops do want the program to perform");
       stoppingPoint =STOPit.nextInt();
       
       for(ask=0; ask<=stoppingPoint; ask++)
        {
            System.out.println("Value of loop="+ ask);
            
        }
        
}
}

