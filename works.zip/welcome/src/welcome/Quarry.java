/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package welcome;

import java.util.Scanner;

/**
 *
 * @author GOODNESS
 */
public class Quarry {
    public static void main(String args[] )
{
    Scanner input=new Scanner(System.in);
    
    int number1;
    int number2;
    String first_name;
    String second_name;
    
    System.out.println("Please kindly enter your age");
    number1=input.nextInt();
     
    System.out.print("Please kindly enter how much you have in your acount ");
    number2=input.nextInt();
    
    
    System.out.println("Please kindly enter your first name: ");
    first_name= input.next();
    
    System.out.println("Please kindly enter your second name: ");
    second_name= input.next();
    
    String full_name;
    full_name=first_name+ " "+second_name;
    
    System.out.println("Your names are "+" "+ full_name);
   System.out.println("You are"+" "+number1+" "+ 
           "years old");
   System.out.println("Your Account Balance is #"+" "+number2);
   System.out.println("THANKS FOR BANKING WITH US");
}



}
