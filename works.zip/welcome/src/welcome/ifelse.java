/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package welcome;

import javax.swing.JOptionPane;


/**
 *
 * @author GOODNESS
 */
public class ifelse {

    public static void main (String args[]){
    
       String name;
       name=JOptionPane.showInputDialog("Please Enter Your Name");
       
        
        String score;
       score= JOptionPane.showInputDialog("Please Enter The Student Score");
       Integer.parseInt(score);
      
       String display= "Your Name is "+name;
       JOptionPane.showMessageDialog(null,display);
       
       if (Integer.parseInt(score)>=0 && Integer.parseInt(score)<=39){
           JOptionPane.showMessageDialog(null,"You FAILED\n,KIndly Exit Please");
       }
       else if (Integer.parseInt(score)>=40 && Integer.parseInt(score)<=44){
           JOptionPane.showMessageDialog(null, "You have an E Grade");
       }
       else if (Integer.parseInt(score)>=45 && Integer.parseInt(score)<=49){
    JOptionPane.showMessageDialog(null, "You Have D Grade");
   }
       else if (Integer.parseInt(score)>=50 && Integer.parseInt(score)<=59){
     JOptionPane.showMessageDialog(null, "You Have C Grade");
}
       else if (Integer.parseInt(score)>=60 && Integer.parseInt(score)<=69){
           JOptionPane.showMessageDialog(null, "You Have B Grade");
  }
       else if (Integer.parseInt(score)>=70 && Integer.parseInt(score)<=100){
    JOptionPane.showMessageDialog(null, "You Have A Grade");
}
       
    }
}