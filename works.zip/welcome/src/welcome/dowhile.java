/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package welcome;

/**
 *
 * @author GOODNESS
 */
public class dowhile {
     public static void main (String [] args){
         int i=0;
         do{
             System.out.println(i+ " ");
         
         i +=2;
         }
         while (i <=101 );
     }
}
