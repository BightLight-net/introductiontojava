/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package welcome;

import java.util.Scanner;

/**
 *
 * @author GOODNESS
 */
public class exp {
    public static void main (String [] args){
        int myloop;
        int multiplier;
        int total;
        int reach;
        
        Scanner STOPit = new Scanner(System.in);
        
        
        do{
        System.out.print("Enter no: ");   
        multiplier = STOPit.nextInt();
          for(myloop= 1; myloop <= 12; myloop++)
        {
            total=multiplier*myloop;
            System.out.println(multiplier + " x " + myloop +"=" +total);
           }
}
        while 
                reach (<=12) 
    }
}