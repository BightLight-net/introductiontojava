/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package welcome;

import javax.swing.JOptionPane;
//import java.util.Scanner;
/**
 *
 * @author GOODNESS
 */
public class Assigment {
 
     public static void main(String []args) {
  //     Scanner input=new Scanner(System.in);
     
       //System.out.println("WELCOME TO NEW HORIZONS UNIVERSITY");
       //System.out.println("PLEASE FILL IN YOUR BIO DATA ");

       String message = "WELCOME TO NEW HORIZONS UNIVERSITY";
       JOptionPane.showMessageDialog(null ,message);
       
        String data = "PLEASE FILL IN YOUR BIO DATA";
       JOptionPane.showMessageDialog(null ,data);
        
       String first_name;
        first_name=JOptionPane.showInputDialog("First Name","Enter your First Name");
        
        String family_name;
        family_name=JOptionPane.showInputDialog("First Name","Enter your First Name");
       
        String age;
         age=JOptionPane.showInputDialog("Please kindly enter your age");
        
         String  gender;
         gender=JOptionPane.showInputDialog("Specify M for Male or F for Female");
        
         
         String matric;
        matric=JOptionPane.showInputDialog("Enter Your Matric No,Seprated BY (/)") ;
        
         String dept;
        dept=JOptionPane.showInputDialog("Please Kindly Enter Your Department") ;
        
      
        
         String ok = "Your Bio Data Are";
       JOptionPane.showMessageDialog(null ,ok);
       
        
        String full_name;
       full_name=first_name+" "+family_name;
       
       
       
       JOptionPane.showMessageDialog(null,full_name,"NAME",JOptionPane.WARNING_MESSAGE);
       JOptionPane.showMessageDialog(null,age,"AGE",JOptionPane.WARNING_MESSAGE); 
       JOptionPane.showMessageDialog(null,gender,"M:Male or F:Female",JOptionPane.WARNING_MESSAGE);
       JOptionPane.showMessageDialog(null,matric,"Matric No.",JOptionPane.WARNING_MESSAGE);
       JOptionPane.showMessageDialog(null,dept,"Enter Your Department",JOptionPane.WARNING_MESSAGE);

       System.exit(0);
      
     }      
    
}
