/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package welcome;
import java.util.Scanner;

/**
 *
 * @author GOODNESS
 */
public class MATH {
public static void main(String args[] )
{
    Scanner input=new Scanner(System.in);
    
    int number1;
    int number2;
    int number3;
    int sum;
    System.out.println("Please kindly enter your age");
    number1=input.nextInt();
     
    System.out.print("Please kindly enter how much you have in your acount ");
    number2=input.nextInt();
    
    System.out.print("Please kindly enter third number, ARE U BORN AGAIN =");
    number3=input.nextInt();
    
    sum=number1 + number2 + number3;
    System.out.printf("THE SUM IS %d\n", +sum);
            
}

}
