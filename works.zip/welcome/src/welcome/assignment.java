/*11
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package welcome;
import java.util.Scanner;
/**
 *
 * @author GOODNESS
 */
public class assignment {
 public static void main (String []args){
     
     Scanner you = new Scanner(System.in);
     
     
     int month;
     System.out.print("Enter number of month");
     month=you.nextInt();
     
     
    switch(month){
        case 1:
      System.out.print(" This month is january ");
      break;
            
        case 2:
        System.out.print("This month is febuary");
       break;
            
             case 3:
        System.out.print("This month is march");
       break;
            
             case 4:
        System.out.print("This month is april");
       break;
            
            
             case 5:
        System.out.print("This month is may");
       break;
            
             case 6:
        System.out.print("This month is june");
       break;
            
    
            case 7:
        System.out.print("This month is july");
       break;
    
     case 8:
        System.out.print("This month is august");
       break;
    
     case 9:
        System.out.print("This month is september");
       break;
    
     case 10:
        System.out.print("This month is october");
       break;
    
     case 11:
        System.out.print("This month is november");
       break;
    
   
          case 12:
        System.out.print("This month is december");
       break;
         
          default:
  System.out.print("Please live now");
       break;
              
    }   
 }    
}
