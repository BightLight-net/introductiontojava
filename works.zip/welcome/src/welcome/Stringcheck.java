/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package welcome;

/**
 *
 * @author user
 */
public class Stringcheck {
    public static void main(String[] args){
        
        String email_address1="meme@me.cob";
        String email_address2="meme@me.com";
        Boolean isMatch =false ;
        
        isMatch = email_address1.equals(email_address2);
        
        if (isMatch==true){
            System.out.println("Email Address Match");
                    
        }else {
            System.out.println("Email sddress don't match");
        }
    }
            
}
