/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package welcome;
import java.util.Scanner;
/**
 *
 * @author user
 */
public class stringsimprt {
    public static void main (String[] args){
        
        Scanner user_input = new Scanner(System.in);
        System.out.println("Quit Y/N");
        
        String aString = user_input.next();
        char aChar = aString.charAt(0);
        
        if (aChar == 'Y'){
            System.out.println("OK, BYE BYE");
        }n
        else {
            System.out.println("Not Quitting");
        }
    }
}
