/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package welcome;

import java.util.Scanner;
        
/**
 *
 * @author GOODNESS
 */
public class nexted {

    public static void main(String args[]){
        Scanner go=new Scanner(System.in);
        
       //float fit= 100; 
        //short fit= 23;
        int a ;
        System.out.println("enter no.");
         a=go.nextInt(); 
        
         
         if (a>70){
            System.out.println("You ought to have retired by now");
        }
        else if (a<70){
            if (a>65 && a<70){
                System.out.println("start preparing for retirement");
            }
            else{
                System.out.println("you've still got  some time in service");
                        
            }
        }
    }     
    
    
}
