/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package welcome;
import javax.swing.JOptionPane;
/**
 *
 * @author GOODNESS
 */
public class compute {
    public static void main (String []args){
        
        JOptionPane.showMessageDialog(null, "THIS PROGRAM DO CALCULATION FOR TWO NUMBERS ");
        
        
   String fnum,snum,answer;
   
   
   
 fnum= JOptionPane.showInputDialog(null, "Enter first Number ");
 Integer.parseInt(fnum);
 
 
    snum= JOptionPane.showInputDialog(null, "Enter second Number ");
 Integer.parseInt(snum);
 
 answer=fnum+snum;
 
 JOptionPane.showMessageDialog(null,answer, "THE ANSWER IS ",JOptionPane.WARNING_MESSAGE);
   
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
}
