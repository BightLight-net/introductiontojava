/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package welcome;

/**
 *
 * @author user
 */
public class Class {
    public static void main(String [] args){
        System.out.printf("%s %d %n", "Total:",  34573);
        
        System.out.printf("%s %10d %n", "Total:",  34573);
        
        System.out.printf(" %-10d  %10d %n", 22334, 34573);
    
         System.out.printf("%.2f  %n", 34.573);  
         
    
    
    
    }
}
