/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package welcome;

import java.util.Scanner;
/**
 *
 * @author GOODNESS
 */
public class swwitch {
    public static void main (String []args){
        Scanner me=new Scanner(System.in);
        
        int month;
        System.out.print("Which month are you trying to find out: ");
        month=me.nextInt();
        switch(month){
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:    
            case 10:
            case 12:
           System.out.println("There are 31 days in this month.");
           break;
             case 4:
             case 6:
            case 9:
             case 11:
             System.out.println("There are 30 days in this month.");
             break;
             
             
             case 2: 
             System.out.println("There are either 28 or 30 days in this month.");   
             break;
             default:
             System.out.println("I do not understand your month entry");     
                 
                
                
        } 
                
    }
}
