/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package welcome;
import java.util.Arrays;
/**
 *
 * @author user
 */
public class Stingarray {
    public static void main(String[] args){
    
    String[] aryString = new String[5] ;
    
    aryString[0] = "This";
    aryString[1] = "is"; 
     aryString[2] = "a";
      aryString[3] = "string";
       aryString[4] = "array";
       
      Arrays.sort(aryString);
      
      int i;
      for(i=0; 1 < aryString.length; i++){
          System.out.println(aryString[1] );
      }
       
}
}
