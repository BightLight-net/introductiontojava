/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package welcome;

import javax.swing.JOptionPane;

public class frame {
    public static void main(String []args) {
        
       System.out.println("THANK YOU FOR SHOPING WITH SHOPRITE");
        String first_name;
        first_name=JOptionPane.showInputDialog("First Name","Enter your First Name");
        
        String family_name;
        family_name=JOptionPane.showInputDialog("First Name","Enter your First Name");
        
       String full_name;
       full_name=first_name+" "+family_name;
       JOptionPane.showMessageDialog(null,full_name,"NAME",JOptionPane.WARNING_MESSAGE);
       
       System.exit(0);
      
       
       
       
       
    }        
    
}
