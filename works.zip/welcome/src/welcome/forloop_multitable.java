/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package welcome;

import javax.swing.JOptionPane;
//import java.util.Scanner;
/**
 *
 * @author GOODNESS^
 */
public class forloop_multitable {
    public static void main (String [] args){
        int myloop;
        String multiplier;
        int total;
        
        //Scanner STOPit = new Scanner(System.in);
        multiplier=JOptionPane.showInputDialog(null,"enter ");
        Integer.parseInt(multiplier);
        //System.out.print("which times table do you want: ");
       // multiplier = STOPit.nextInt();
        
        for(myloop= 1; myloop <= 12; myloop++)
        {
            total=Integer.parseInt(multiplier)*myloop;
            //System.out.println(multiplier + " x " + myloop +"=" +total);
       String display=multiplier + " x " + myloop +"=" +total;
            JOptionPane.showMessageDialog(null,display, "THE ANSWER IS ",JOptionPane.WARNING_MESSAGE); 
        }
        
    }
}
