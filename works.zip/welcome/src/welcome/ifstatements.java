/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package welcome;

import javax.swing.JOptionPane;
/*
 *
 * @author GOODNESS
 */
public class ifstatements    {
    
    public static  void main(String[] args){
    
       // int input;
        
   //String input;
    String message=("WELCOME TO FEDERAL ROAD SAFTY COMMISSION");
       JOptionPane.showMessageDialog(null, message);
    
    String  input;
    input=JOptionPane.showInputDialog("Plese Kindly Enter your Age");
    Integer.parseInt(input);    
   
       
       if(Integer.parseInt(input)>= 18){
            JOptionPane.showMessageDialog(null," Your Are Legible For Driving Lisence.");
        } else
         JOptionPane.showMessageDialog(null," Your Can Apply For A Driving School");  
    }
}
