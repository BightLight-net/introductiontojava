/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package welcome;

import java.util.Scanner;

/**
 *
 * @author user
 */
public class assigment3 {
    public static void main (String[] args){
         Scanner plot = new Scanner(System.in);
         
         System.out.print("Please enter your name");
         String collect = plot.nextLine();
         
         char aChar = collect.charAt(0);
         
         System.out.print(aChar);
         
         
         int space = collect.indexOf(" ");
         System.out.println("dear "+collect+ " "+ " ykunour intials are: "+collect.charAt(0)+ collect.charAt(space+1));
          //collect =user_input.next() ;
          //int result;
        //result = collect.indexOf(ampersand);
        //System.out.println(result);
        
        
        
        
         
         
         
    }
}
