 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package welcome;

/**
 *
 * @author user
 */
public class StringManup {
    public static void main(String[] args){
        int result;
        String Word1 = "Ape";
        String Word2 = "App";
        
        result = Word1.compareTo(Word2);
        
        if(result < 0){
        
        
        System.out.println("Word1 is less than word1");
      }
        else if (result>0 ){
            System.out.println("Word1 is more than word2");
        }    
        else if (result == 0){
            System.out.println("The same word");
        }      
      }
}