/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package welcome;

/**
 *
 * @author user
 */
public class stringsmanipu {
   public static void main (String[] args){
       
       char ampersand ='@';
       String dotCom =".com";
       String email_address = "meme@me.com";
        
       
       int atPos = email_address.indexOf(ampersand);
       int result;
       result = email_address.indexOf( ampersand);
       
       if (result == -1){
               System.out.println("Invalid Email Address");
                       }
               
               else {
                       System.out.println("Email address Ok" + result );
                               }
   } 
}
