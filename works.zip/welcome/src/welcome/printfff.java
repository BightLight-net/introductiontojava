/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package welcome;

/**
 *
 * @author user
 */
public class printfff {
    public static void main(String[] args){
        
        String heading1 = "Exam_Name";
        String heading2 = "Exam_GRADE";
        String divider = "--------------------------------------------";
        
        
         String course1 = "Java"; String grade1 = "A";
         String course2 = "PHP"; String grade2 = "B";
        String course3 = "VB NET"; String grade3 = "A";
        
        System.out.println("");
        System.out.printf("%-15s  %15s %n", heading1, heading2);
        System.out.println(divider);
        
        System.out.printf("%-15s %10s %n", course1, grade1);
        System.out.printf("%-15s %10s %n", course2, grade2);
        System.out.printf("%-15s %10s %n", course3, grade3);
        
        System.out.println(divider);
        System.out.println("");
        
    }
}
