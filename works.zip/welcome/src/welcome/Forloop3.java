/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package welcome;

import java.util.Scanner;

/**
 *
 * @author GOODNESS
 */
public class Forloop3 {
     public   static void main (String []args){
        int ask;
        int again;
        //int stoppingPoint=40;
        Scanner STOPit=new Scanner (System.in);
        
        
        
       int stoppingPoint;
       System.out.println("where do you want your ending point");
       stoppingPoint =STOPit.nextInt();
       
       
       
       System.out.println("where do you want your starting point");
       ask =STOPit.nextInt();
       
       
       for( again=ask;  ask <= stoppingPoint; ask++)
        {
            System.out.println("Value of loop="+ ask);
            
        }
    
     }
 
}

