/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package welcome;
import java.util.*;
/**
 *
 * @author user
 */
public class arraylist {
    public static void main(String[] args){
       
        ArrayList listTest = new ArrayList();
        
        listTest.add("first item");
        listTest.add("second item");
        listTest.add("third item");
        listTest.add(7);
        
        Iterator it = listTest.iterator();
        
        while (it.hasNext()){
            System.out.println(it.next());
        }
        listTest.remove("second item");
        
        System.out.println("Whole list=" + listTest);
        
        System.out.println("postion 1="+ listTest.get(1));
    }
}
