/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package welcome;

/**
 *
 * @author GOODNESS
 */
public class ForLoops {

    public   static void main (String []args){
        int ask;
        int stoppingPoint=40;
        
        
        for(ask=10; ask<=stoppingPoint; ask++)
        {
            System.out.println("Value of loop="+ ask);
            
        }
        
       // System.exit(0);
        
    }
    
    
    
}
