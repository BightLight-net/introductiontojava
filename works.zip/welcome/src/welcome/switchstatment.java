/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package welcome;

/**
 *
 * @author GOODNESS
 */
public class switchstatment {
    public static void main (String arg[]){
        
        int age;
        age=3;
        switch (age){
            case 1:
                System.out.println("you can crawl");
                break;
                
            case 2:
                System.out.println("you can talk");
            case 3:
                System.out.println("you can get in trouble");
                break;
            default:
                System.out.print("I don't know how old you are");
        }
    }
}
