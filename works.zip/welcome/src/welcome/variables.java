*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package welcome;

/**
 *
 * @author GOODNESS
 */
public class variables {
    public static void main(String[] arg){
        
        int firstname=30;
        int secondname=60;
        float thirdname=78.98f;
        
        double java;
        java=firstname +secondname +thirdname;
        System.out.println("THANK YOU FOR SHOPING WITH SHOPRITE");
        System.out.println("YOUR TOTAL BALANCE IS #"+ java); 
       
        
         
        
        

    }
}
