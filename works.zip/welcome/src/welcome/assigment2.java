/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package welcome;
import java.util.Scanner;
/**
 *
 * @author GOODNESS
 */
public class assigment2 {
    public static void main (String [] args){
        int myloop;
        int multiplier;
        int total;
        
        Scanner STOPit = new Scanner(System.in);
        
        System.out.print("Enter 1: ");
        multiplier = STOPit.nextInt();
        
          for(myloop= 1; myloop <= 12; myloop++)
        {total=multiplier*myloop;
            System.out.println(multiplier + " x " + myloop +"=" +total);
           }
         
        System.out.print("Enter 2: ");
        multiplier = STOPit.nextInt();
        
          for(myloop= 1; myloop <= 12; myloop++)
        {total=multiplier*myloop;
            System.out.println(multiplier + " x " + myloop +"=" +total);
    } 
        System.out.print("Enter 3: ");
        multiplier = STOPit.nextInt();
        
          for(myloop= 1; myloop <= 12; myloop++)
        {total=multiplier*myloop;
            System.out.println(multiplier + " x " + myloop +"=" +total);
    
    }
           
        System.out.print("Enter 4: ");
        multiplier = STOPit.nextInt();
        
          for(myloop= 1; myloop <= 12; myloop++)
        {total=multiplier*myloop;
            System.out.println(multiplier + " x " + myloop +"=" +total);
    }
     
        System.out.print("Enter 5: ");
        multiplier = STOPit.nextInt();
        
          for(myloop= 1; myloop <= 12; myloop++)
        {total=multiplier*myloop;
            System.out.println(multiplier + " x " + myloop +"=" +total);
        
        }
     
        System.out.print("Enter 6: ");
        multiplier = STOPit.nextInt();
        
          for(myloop= 1; myloop <= 12; myloop++)
        {total=multiplier*myloop;
            System.out.println(multiplier + " x " + myloop +"=" +total);
        }
     
        System.out.print("Enter 7: ");
        multiplier = STOPit.nextInt();
        
          for(myloop= 1; myloop <= 12; myloop++)
        {total=multiplier*myloop;
            System.out.println(multiplier + " x " + myloop +"=" +total);
         
        System.out.print("Enter 8: ");
        multiplier = STOPit.nextInt();
        
          for(myloop= 1; myloop <= 12; myloop++)
        {total=multiplier*myloop;
            System.out.println(multiplier + " x " + myloop +"=" +total);
        }
         
        System.out.print("Enter 9: ");
        multiplier = STOPit.nextInt();
        
          for(myloop= 1; myloop <= 12; myloop++)
        {total=multiplier*myloop;
            System.out.println(multiplier + " x " + myloop +"=" +total);}
         
        System.out.print("Enter 10: ");
        multiplier = STOPit.nextInt();
        
          for(myloop= 1; myloop <= 12; myloop++)
        {total=multiplier*myloop;
            System.out.println(multiplier + " x " + myloop +"=" +total);}
         
        System.out.print("Enter 11: ");
        multiplier = STOPit.nextInt();
        
          for(myloop= 1; myloop <= 12; myloop++)
        {total=multiplier*myloop;
            System.out.println(multiplier + " x " + myloop +"=" +total);
        }
            System.out.print("Enter 12: ");
        multiplier = STOPit.nextInt();
        
          for(myloop= 1; myloop <= 12; myloop++)
        {total=multiplier*myloop;
            System.out.println(multiplier + " x " + myloop +"=" +total);
        }
        }
    }}
