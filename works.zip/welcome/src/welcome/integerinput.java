
package welcome;

import javax.swing.JOptionPane;


public class integerinput {
    public static void main (String []args){
        String number1 = JOptionPane.showInputDialog("Enter the First number");
        Integer.parseInt(number1);
        
        String number2 = JOptionPane.showInputDialog("Enter Second number");
        Integer.parseInt(number2);
        
        int addition =Integer.parseInt(number1) * Integer.parseInt(number2);
            String display = number1+" X " +number2+" = " + addition;
            
            JOptionPane.showMessageDialog(null,display); 
    }
     
        
        
    
           
}
