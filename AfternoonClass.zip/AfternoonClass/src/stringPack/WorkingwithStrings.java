
package stringPack;


public class WorkingwithStrings {

    
    public static void main(String[] args) {
       String tense = "we are in class";
       String time = "today";
       
       System.out.println(tense.length());
       System.out.println(tense.toUpperCase());
       boolean num = tense.contains("d");
       System.out.println(tense.endsWith("s"));
       System.out.println(tense.substring(4));
       System.out.println(tense.indexOf(" "));
       System.out.println(tense.substring(3, 7));
       System.out.println(tense.concat(time)); // checks if string is empty
       System.out.println(tense.replace('a','O'));
       System.out.println(tense.charAt(4));
       
       
       
       
       
       
       
       
    }
    
}
