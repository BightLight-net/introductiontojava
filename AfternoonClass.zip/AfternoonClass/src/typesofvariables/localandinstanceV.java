h
package typesofvariables;

/**
 *
 * @kunle java
 */
public class localandinstanceV {
    //instance variable
    public String myVar = "instance variable";
    
    public void ourMethod(){
    // local variable 
        String myVar = "Inside Method";
        this.myVar = myVar;
        System.out.print(myVar);
    }

    public static void main(String[] args) {
        // Creating object reference
        localandinstanceV idowu = new localandinstanceV();
        
        
      idowu.ourMethod(); //method calling
      System.out.println(idowu.myVar);
        
        
      // Categories of variables [primitive and object reference varaible]
        // Types of variables [local, instance and static]
        
        
        
    }
    
}
