
package Encapsulate;


public class SecondClass {

   
    public static void main(String[] args) {
       
        Firstclass  obj = new Firstclass();
        
        
       System.out.print(obj.displayPrice()); 
       
        
        
    }
    
}
