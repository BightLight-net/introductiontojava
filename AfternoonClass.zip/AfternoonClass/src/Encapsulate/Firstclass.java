/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Encapsulate;

/**
 *
 * @author HP
 */
public class Firstclass {
    private int price = 4566;
    
    public int displayPrice(){
    
    return price;
    } 
    
}
