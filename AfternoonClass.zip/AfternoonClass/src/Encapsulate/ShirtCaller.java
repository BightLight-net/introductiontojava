
package Encapsulate;


public class ShirtCaller {

    
    public static void main(String[] args) {
      Shirt theShirt = new Shirt() ;
      Shirt ourShirt = new Shirt() ;
      
      theShirt.setColorCode('Y');
      theShirt.setShirtID(5);
      
      	System.out.println("Color Code: " + theShirt.getColorCode());
        System.out.println("Color Code: " + theShirt.getShirtID());
      
      ourShirt.setColorCode('I');
      ourShirt.setShirtID(66);
      
      	System.out.println("Color Code: " + ourShirt.getColorCode());
        System.out.println("Color Code: " + ourShirt.getShirtID());
      
      
      
        
        
    }
    
}
