/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Encapsulate;

/**
 *
 * @author HP
 */
public class Info {
    private int ssn =67;
    private String empName;
    private int empAge;
    
    
    
    //Getter and Setter methods
     public int getEmpSSN(){
        return ssn;
    }
     
   public String getEmpName(){
        return empName;
    }
   
   public int getEmpAge(){
        return empAge;
    }
   
    public void setEmpAge(int newValue){
        empAge = newValue;
    }
    
    public void setEmpName(String newValue){
        empName = newValue;
    }
    
   public void setEmpSSN(int newValue){
        ssn = newValue;
    } 
    
    
}
