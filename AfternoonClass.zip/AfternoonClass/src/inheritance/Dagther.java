
package inheritance;

public class Dagther extends Mother {

    
    public static void main(String[] args) {
       Dagther d = new Dagther();
        String daughtersCharacter = d.character();
        
        
        System.out.println("She is "+daughtersCharacter);
        System.out.println("My religion is "+d.faith());
        
        
        double inheritedWorth = d.financialWorth(); 
        System.out.println("My religion is "+inheritedWorth);
    }
    
}
