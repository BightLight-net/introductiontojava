/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance;

/**
 *
 * @author HP
 */
public class Grandma {
    
    public double financialWorth(){
        return 56002300;
    }
    public int serviceYear(){
        return 35;
    }
    public String marriage(){
        return "monogamy";
    }
    
}
