
package inheritance;

import javax.swing.JOptionPane;
public class Mother extends Grandma{
    
     public String character(){
        return "disrespectful";
    }
    @Override
    public double financialWorth(){
        return 230290.0;
    }
    public String faith(){
        return "Atheist";
    }

    
    public static void main(String[] args) {
        Mother  m = new Mother();
        JOptionPane.showMessageDialog(null, m.financialWorth());
        
        
        
    }
    
}
