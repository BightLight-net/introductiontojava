
package revision;

public class Variables {


    public static void main(String[] args) {
    // premitive variable
        int age = 88;
        double current = 35.43;
        long num = 44444343;
        short num1 =33;
        float num2 = 34.33f;
        char ch = 'r';
        boolean choice = true;
        
        
        //String is a class
        String message ="this is a sentense";
        
        
    }
    
}
