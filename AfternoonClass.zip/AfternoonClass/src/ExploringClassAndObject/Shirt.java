
package ExploringClassAndObject;


public class Shirt {
    
    char colorCode;
    int size ;
    
    public void designerDisplay(String des){
    
        String changeDesign = des + "Gucci";
    System.out.print(changeDesign);
    }
    
    
    public int changeSize(int size){
    
        int newSize = size+20;
    return newSize;
    }
    
}
