
package MoreArgument;


public class Score {
    private int score;
    public int setScore(int s){
        if(s >= 0 && s <=100){
            score = s;
        
        
        }
        return score;
    }
    
    
    
    public int getScore(){
    
    return score + 40;
    }
    
    
    
    
}
