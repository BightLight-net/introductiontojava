
package MoreArgument;


public class Cap1 {

    
    public static void main(String[] args) {
        
        Cap2 c2 = new Cap2();
        Cap2 c3 = new Cap2();
       
        System.out.println(c2.setName("madela"));
         
        System.out.println(c2.getName());
        
         System.out.println(c2.setAge(50));
        System.out.println(c2.getAge());
        
       
        
        
        
        
        
        
        
        
        
        
    }
    
}
