
package MoreArgument;

import java.util.Scanner;
public class Shirt {
    Scanner Object = new Scanner(System.in);
    
    
    public char colorcode = Object.next().charAt(0); 
    
}
