
package MoreArgument;


public class ShoppingCart {

    
    public static void main(String[] args) {
        Shirt myShirt = new Shirt();
        System.out.println("Shirt color: " + myShirt.colorcode);
        changeShirtColor(myShirt,'B');
        System.out.println("Shirt color: " + myShirt.colorcode);
       // System.out.println("Shirt color: " + theShirt.colorcode);
    }
    public static void changeShirtColor(Shirt theShirt,char color){
        theShirt = new Shirt();
    theShirt.colorcode =color;
    System.out.println("Shirt color: " + theShirt.colorcode);
    }
    
}
