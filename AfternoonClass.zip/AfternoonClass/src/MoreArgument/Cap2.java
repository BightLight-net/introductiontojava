
package MoreArgument;


public class Cap2 {
    private String name = "Mandela";
    
    private int age =  24;
    private double salary;
    
     public String setName(String name){
    this.name = name;
    return name;
    }
    
     public int setAge(int age){
   this.age = age;
   return age;
    }
    
    public int getAge(){
    return age;
    }
    
    public String getName(){
         return name;
     }
      
    
    public double setSalary(double salary){
    
        this.salary = salary;
        
        return salary;
       
    }
    
    public double getSalary(){
    
        
        return salary;
    }
    
    
}
