
package Projects;


public class HectoDec {

    
    public static void main(String[] args) {
     
        String Hex = "95ADC";
        int num =0;
        double dec =0;
        int decimal =0;
        //char [] ch = new char[Hex.length
        char ch;
        
       
        
        
       // for(int i =0 ; i< Hex.length() ; i++){
            
            
        
            //String  = Hex.charAt(i);
           
           //String nummber = new String(ch); 
           decimal = Integer.parseInt(Hex, 16);
           
           
           
//           if( ch == 'A' ){
//           num = 10;
//           
//           }else if (ch  == 'B'){
//           num = 11;
//           } else if(ch == 'C'){
//           num= 12;
//           } else if (ch =='D'){
//           num = 13;
//           } else if (ch == 'E'){
//           num = 14;
//           }else if (ch == 'F'){
//           num = 15;
//           }
//           else{
//               switch(ch){
//                   case '0':num = 0;
//                       break;
//                   case '1': num = 1;
//                       break;
//                   case '2': num = 2;
//                       break;
//                    case '3': num = 3;
//                       break;
//                     case '4': num = 4;
//                       break;
//                      case '5': num = 5;
//                       break;
//                      case '6': num = 6;
//                       break;
//                        case '7': num = 7;
//                       break;
//                         case '8': num = 8;
//                       break;
//                          case '9': num = 9;
//                       break;
//                          default: System.out.print("pls check again");
//                              break;
//                    
//               
               
            //   }
        System.out.println(decimal);
           
           
           
           }
           
           //dec =  num * Math.pow(16,i);
          // System.out.println(dec);
           
           
            
            
        }
        
        //System.out.println(dec);
        
        
        
        
    
    
