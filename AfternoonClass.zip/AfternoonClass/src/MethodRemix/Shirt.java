
package MethodRemix;


public class Shirt {
    
     public String description ;
   public  char colorCode ;
    public double price;
    
    // Constructor
   public  Shirt (){
       description = "--description required--";
       colorCode = 'U';
       price = 0.00;
    
       display();      // called normally
       
    }
    
    
    public void display(){
    System.out.println("Shirt description" + description);
     System.out.println("Color Code" + colorCode);
      System.out.println("Shirt Price" + price);
    
    
    }
    
    
    
    
    
}
