
package MethodRemix;

public class ShoppingCart {

 
    public static void main(String[] args) {
        
        Shirt myshirt = new Shirt();
        
     
        
        
        
        
    }
    
}
