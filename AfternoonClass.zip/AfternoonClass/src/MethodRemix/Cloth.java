
package MethodRemix;

public class Cloth {
    
     public String description ;
   public  char colorCode ;
    public int price;
    
    
   public Cloth(String desc, char color , int price){
      this.description = desc;
        this.colorCode = color;
        this.price =  price;
    }
    
    
//    public void setField(String desc, char color , int price){
//          
//        this.description = desc;
//        this.colorCode = color;
//        this.price =  price;
//        
//    }
    
    
    
}
