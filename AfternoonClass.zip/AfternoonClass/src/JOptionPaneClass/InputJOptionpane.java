
package JOptionPaneClass;

import javax.swing.JOptionPane;
public class InputJOptionpane {


    public static void main(String[] args) {
        
        String fname = JOptionPane.showInputDialog("First Name");
        
        String sname = JOptionPane.showInputDialog("Surname");
        
        String fullname = "Your name is "+ fname +" "+ sname;
        
        JOptionPane.showMessageDialog(null, fullname);
        System.exit(0);
        
    }
    
}
