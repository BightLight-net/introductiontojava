
package loops;


public class Breakinloops {
   static int tolow = 19;
  static  int tohigh = 48;

   
    public static void main(String[] args) {
       // Breakinloops obj = new Breakinloops();
        int[] temp = {25,30,31,32,38,30,40,48,45,20,19,15};
        
        for(int cent : temp){
            
            if(cent < tolow || cent > tohigh){
            break;
            //continue;
            }
            
            
            System.out.println(cent+" is sutable for human");
        
        
        }
        
        
    }
    
}
