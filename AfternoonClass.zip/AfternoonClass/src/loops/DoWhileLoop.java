
package loops;

public class DoWhileLoop {

    
    public static void main(String[] args) {
      int i =10; 
        do{
        System.out.println(i);
        i=-2;
        
        }while (i>1);
        
        
    }
    
}
