
package loops;

import java.util.Scanner;
public class whiledo {
 
    public static void main(String[] args) {
        /*
        while (condition) {
        increment
        }
        */
        Scanner ejiro = new Scanner(System.in);
        
        System.out.println("Hello! Hw old are you:");
        
        int age=ejiro.nextInt();
        while(age <18){
            
            System.out.println("your current age is: "+age);
            age+=2;  
    }
    
}
}