
package loops;


public class MoreLoop {

    public static void main(String[] args) {
       /*
        for (initialize; condition; increment/decrement){
        
        code in here
        }
        
        
        */
        
       int n=1,i,j;
        
        for(i =0; i<=10; i++ ){
                for(j= 0; j< 10; j++){
                    System.out.print(n +" ");
                    n++;
                }
        System.out.println();
        }
        
        
        
    }
    
}
