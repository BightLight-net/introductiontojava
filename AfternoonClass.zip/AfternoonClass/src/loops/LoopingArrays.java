
package loops;


import java.util.Scanner;
public class LoopingArrays {

    
    public static void main(String[] args) {
        Scanner obj = new Scanner(System.in);
        System.out.println("enter cars into the garage");
        String fcar = obj.next();
         String scar = obj.next();
          String tcar = obj.next();
           String frcar = obj.next();
        
        
        
        
        //this is a comment
        
        /*this is 
        for mutiple lines of code*/
        
        String[] garage = new String[5];
        
        garage[0] = fcar;
        garage[1] = scar;
        garage[2] = tcar;
        garage[3] = frcar;
        garage[4] = "Maybach";
        
        for( String car: garage ){
        System.out.println("Our  car  " + car);
        }
        
        
        
        
        
    }
    
}
