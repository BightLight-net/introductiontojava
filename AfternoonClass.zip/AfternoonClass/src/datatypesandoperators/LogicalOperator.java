
package datatypesandoperators;

public class LogicalOperator {

   
    public static void main(String[] args) {
       boolean b1 = true;
       boolean b2 = false;
       
       System.out.println("b1 && b2: " + (b1 && b2)); //false
       System.out.println("b1 || b2: " + (b1 || b2)); //true

       System.out.println("!(b1 && b2): " + !(b1 && b2)); //true
       
       /*Relational Operator*/
       int num1 = 10;
      int num2 = 50;
      
      if(num1 ==num2){
      System.out.print("num1 and num2 are equal");
      }else{
      System.out.print("num1 and num2 are not equal");
      }
      
       if(num1 !=num2){
      System.out.print("num1 and num2 are not equal");
      }else{
      System.out.print("num1 and num2 are  equal");
      }
       
        if(num1 > num2){
      System.out.print("num1 is greater than num2");
      }else{
      System.out.print("num1 is not greater than num2");
      }
      
      
       
       
       
    }
    
}
