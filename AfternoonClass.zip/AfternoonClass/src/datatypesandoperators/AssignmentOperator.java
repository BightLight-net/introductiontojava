
package datatypesandoperators;

public class AssignmentOperator {

    public static void main(String[] args) {
   
        int num1 = 100;
        int num2 = 200;
        
        num2 = num1;
        System.out.println("= Output: " +num2 ); //100
        
        num2 += num1; // meaning num2 = num2 + num1
        System.out.println("= Output: " +num2 ); //200
        
        num2 -= num1; //meaning num2 = num2 - num1
        System.out.println("= Output: " +num2 ); //100
        
        num2 *= num1;
        System.out.println("= Output: " +num2 ); //10000
        
        num2 /= num1;
        System.out.println("= Output: " +num2 ); //100
        
        num2 %= num1;
        System.out.println("= Output: " +num2 ); //0
        
        
        /*Auto Operator*/
         num1++;
         num2++;
         System.out.println("num1++ Output: " +num1 );
         System.out.println("num2++ Output: " +num2 );
         
         
        
        
        
        
    }
    
}
