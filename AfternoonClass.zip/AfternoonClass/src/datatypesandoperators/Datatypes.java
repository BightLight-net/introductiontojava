
package datatypesandoperators;

public class Datatypes {

  
    public static void main(String[] args) {
       
        // There two categories of variables...
        // primitive variables and object reference
        
        /* Thare are three types of variables
        instance variable
        static variables
        local variables
        
        */
        
        short var1 = 23;
        byte  var2 = 100;
        long var3 = 1233;
        int var4 =34045;
        float var5 =344.45f;
        double var = 3343333.55;
        boolean var7 = true;
        char var8= 'e';
        
        
        String var9 = "this is java class ";
        
        
        
        
        
        
        
        
    }
    
}
