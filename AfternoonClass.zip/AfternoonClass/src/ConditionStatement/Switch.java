
package ConditionStatement;


public class Switch {

    
    public static void main(String[] args) {
       int num = 5;
       
       switch(num)
       {
           case 1:
               System.out.println("This is number one");
               break;
           case 2:
               System.out.println("This is number two");
               break;
           case 3:
               System.out.println("This is number three");
               break;
           case 4:
               System.out.println("This is number four");
               break;
           case 5:
               System.out.println("This is number five");
               break;
           case 6:
               System.out.println("This is number six");
               break;
           case 7:
               System.out.println("This is number seven");
               break;
           default:
               System.out.println("Default will display when none is selected");
                    
       }
        
        
        
    }
    
}
