
package Exception;


public class Util {
    public void doThis(){
        try{
            doThat();
                   
        
        }catch(Exception e){
        System.out.println("doThis - " +"Exception caught: " + e.getMessage() );
        }
    
// SQLException, IOException, ClassNotFoundException 
    }
    
    public void doThat() throws Exception{
    
        System.out.println("doThat: Throwing exception");
        throw new Exception("Ouch!");
        
    
    }
    
}
