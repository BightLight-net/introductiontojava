
package Exception;


public class UtillCaller {

    
    public static void main(String[] args) {
        // TODO code application logic here
        Util theUtil = new Util();
        theUtil.doThis();
        System.out.println("Back to main Method");
    }
    
}
