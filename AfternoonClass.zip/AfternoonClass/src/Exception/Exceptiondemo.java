
package Exception;

import java.util.Scanner;


public class Exceptiondemo {

    
    public static void main(String[] args) {
        
        
        try {
             domath();
                
        } catch(ArithmeticException e){
        System.out.println(e.getMessage());
 System.out.println("you attempted to divide by zero");    
        
        }
        catch(ArrayIndexOutOfBoundsException e){
        System.out.println(e.getMessage());
        } catch(Exception e){
        System.out.println(e.getMessage());
        }finally{
        //System.out.println("It will always work ");
            System.out.println("Denomenator must not be equal to Zero ");
            domath();
            
        
        
        }
    
                        
    }
    public static void domath(){
        Scanner scan =  new Scanner(System.in); 
    System.out.println("Please enter first Number ");
            int b = scan.nextInt();
            
             System.out.println("Please enter second Number ");
            
            int c = scan.nextInt();
            System.out.println(b/c);
    
    }
    
}
