/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package condition;
import java.util.Scanner;
import javax.swing.JOptionPane;
public class Condition {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    Scanner input= new Scanner(System.in);
       int age ;
       JOptionPane.showMessageDialog(null, "show");
       System.out.println("Please, enter your age");
       age= input.nextInt();
       
        
      if (age<20){
       //String age;
           //age = JOptionPane.showInputDialog("Enter your age");
           //age=input.next();
          String young= "You are too young to enroll";
           String old = "You are too old to enroll";
           String ok = "You are allowed to enroll";
        
          JOptionPane.showMessageDialog(null,"young");
       //System.out.println("You are  too young to enroll");
           
       }
       else if (age==20) {
           String young= "You are too young to enroll";
           String old = "You are too old to enroll";
           String ok = "You are allowed to enroll";
           JOptionPane.showMessageDialog(null, "ok");
           //System.out.println("You are allowed to enroll");
       }
       else{
String young= "You are too young to enroll";
           String old = "You are too old to enroll";
           String ok = "You are allowed to enroll";
           JOptionPane.showMessageDialog(null, "old");
//System.out.println("You are too old to enroll");
       };
    
    }}
