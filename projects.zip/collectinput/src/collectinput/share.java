package collectinput;

import java.util.Scanner;

public class share {
    
    public static void main(String[] args) {
      
       Scanner dabra = new Scanner( System.in );
       
       String first_name;
       System.out.println("Please enter your first name:  ");
       first_name = dabra.next( );
       
       String family_name;
       System.out.println("Please enter your family name, Not your father's name: ");
       family_name = dabra.next();
       
       String full_name;
       full_name = first_name + " " + family_name;
       
        System.out.println("************************************************************" );
       
       System.out.println("Your name's are: " + full_name);
       
       System.out.println("************************************************************" );
       
        





    }
    
}
