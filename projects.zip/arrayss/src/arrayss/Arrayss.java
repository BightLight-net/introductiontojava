/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package arrayss;

/**
 *
 * @author user
 */
public class Arrayss {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
       
        int[] aryNums;
        aryNums = new int[6];
        
        aryNums[0]= 10;
        aryNums[1]= 14;
        aryNums[2]= 36;
        aryNums[3]= 27;
        aryNums[4]= 43;
        aryNums[5]= 50;

    System.out.println( aryNums[2]);
    
    }
}
        // TODO code application logic here
    
    

