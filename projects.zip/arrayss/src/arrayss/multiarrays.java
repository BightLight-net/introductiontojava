/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package arrayss;

/**
 *
 * @author user
 */
public class multiarrays {
    public static void main(String[] args){
        
        int[][] aryNumbers=new int[6][5];
        
        aryNumbers[0][0]=10;
        aryNumbers[0][1]=14;
        aryNumbers[0][2]=16;
        aryNumbers[0][3]=19;
        aryNumbers[0][4]=20;
        
  
        aryNumbers[1][0]=34;
        aryNumbers[1][1]=23;
        aryNumbers[1][2]=78;
        aryNumbers[1][3]=19;
        aryNumbers[1][4]=19;
        
        aryNumbers[2][0]=33;
        aryNumbers[2][1]=34;
        aryNumbers[2][2]=23;
        aryNumbers[2][3]=78;
        aryNumbers[2][4]=19;
        
        
        
        aryNumbers[3][0]=19;
        aryNumbers[3][1]=34;
        aryNumbers[3][2]=26;
        aryNumbers[3][3]=34;
        aryNumbers[3][4]=19;
        
         aryNumbers[4][0]=32;
        aryNumbers[4][1]=34;
        aryNumbers[4][2]=26;
        aryNumbers[4][3]=99;
        aryNumbers[4][4]=167;
        
         aryNumbers[5][0]=19;
        aryNumbers[5][1]=34;
        aryNumbers[5][2]=26;
        aryNumbers[5][3]=34;
        aryNumbers[5][4]=19;
        
        
        
        
    int rows=6;
    int coloums=5;
    
    int i,j;
    
    for(i=0; i<rows; i++){
        
        for(j=0; j<coloums; j++){
            
            System.out.print(aryNumbers[i][j] +" ");
        }
                System.out.println("");
                
              
    }
    }
}
