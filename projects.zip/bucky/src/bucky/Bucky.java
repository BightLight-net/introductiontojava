/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package bucky;

/**
 *
 * @author GOODNESS
 */
public class Bucky {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
     system.out.println("Hello java!");   
    }
}
