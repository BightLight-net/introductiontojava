

package area_rectangle;

import javax.swing.JOptionPane;

/**
 *
 * @kunle mike Akintola
 * 
 */
public class example {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
    String wel="***** This program Calculate Area of a rectangle*****";
    JOptionPane.showMessageDialog(null,wel,"welcome",JOptionPane.INFORMATION_MESSAGE);
    
    String breath;
    breath = JOptionPane.showInputDialog("breath","please enter breath of the rectangle");
    
    String length;
    length = JOptionPane.showInputDialog("length","Please enter length of the rectangle");
    
   int area = Integer.parseInt(breath) * Integer.parseInt(length);
   //String result = "The Area of the Rectangle is: " + area ;
   JOptionPane.showMessageDialog(null,"The Area of the Rectangle is: " + area ,"Area",JOptionPane.QUESTION_MESSAGE);
    
    
    }
    
}
