/*Another useful class for accepting user input, and displaying results, is the JOptionPane class
This is located in the javax.swing library. 
*/

package WorkingWithJOptionPane;

import javax.swing.JOptionPane;
public class JOptionPane_Class {

    
    public static void main(String[] args) {
        String First_display = "*********Welcome to Java University*******";
        JOptionPane.showMessageDialog(null,First_display);
        
        String fname;
        fname = JOptionPane.showInputDialog("Enter Your First name");
        
        String sname;
        sname = JOptionPane.showInputDialog("Enter Your Second name");
         
        String Fullname = fname + " " + sname;
        
        String dept = JOptionPane.showInputDialog("Enter Your Department");
        
        String Faculty = JOptionPane.showInputDialog("Enter Your Faculty");
        
        String country = JOptionPane.showInputDialog("Enter Your Country");
        
        String aLevel_Yrs = JOptionPane.showInputDialog("Enter The Years use in Sec.");
        
        String pri_Yrs = JOptionPane.showInputDialog("Enter The Years use in Primary Sch.");
        
        int TotalYrs = Integer.parseInt(aLevel_Yrs) + Integer.parseInt(pri_Yrs);
        

        
        String Second_display = Fullname + "\n" + "Your department is " + " " + dept + "\n"
                + " It's in " + " "+ Faculty + " " + " Faculty" + "\n"
                + "Total years spent in O Level is  " + TotalYrs+ " " + "\n"
                + "From " + country ;
        
               
        JOptionPane.showMessageDialog(null, Second_display, "Output", JOptionPane.WARNING_MESSAGE);
        
    
       System.exit(0);
    }
    
}
