
package working_SwitchCondition;


public class SwitchCondition {

   
    public static void main(String[] args) {
        // TODO code application logic here
        int product= 500;
        
        switch(product){
            case 200:
                System.out.println("Your Mtn card is #200");
                break;
            case 300:
                System.out.println("Your POPPY drink is #300");
                break;
            case 400:
                System.out.println("Bread is #400");
                break;
            case 500:
                System.out.println("two chicken pie in foodco");
                break;
            case 600:
                System.out.println("Milo small size is #600");
                break;
            case 700:
                System.out.println("Smart collection deodorant");
                break;
                
            default:
                System.out.println("please use the POS, Thank you for coming");
                       
        
        }
        
        
        
        
    }
    
}
