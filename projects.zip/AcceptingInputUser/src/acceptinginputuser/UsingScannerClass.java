/*
One of the strengths of Java is the huge libraries of code available to you.
All you need to do is to reference which library you want to use,
and then call a method into action.
One really useful class that handles input from a user is called the Scanner class
 The Scanner class can be found in the java.util library
*/
package acceptinginputuser;

import java.util.Scanner;

public class UsingScannerClass {
    
    public static void main(String[] args) {
        Scanner ObjectCreated = new Scanner(System.in);
        
        String first_name;
        System.out.println("Enter Your first name: ");
        first_name = ObjectCreated.next();
        
         String family_name;
        System.out.println("Enter Your Surname name: ");
        family_name = ObjectCreated.next();
        
        String full_name;
        full_name = first_name + " " + family_name;
        
         System.out.println(" Your full name are " + full_name);
         
               
        
             
    }
    
}
