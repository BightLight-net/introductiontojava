
package codevilla;

import java.util.Scanner;


public class CodeVilla {

   
    public static void main(String[] args) {
        // TODO code application logic here
    Scanner inputHex = new Scanner(System.in);
   System.out.print("Enter the Hex value");
  
   String Hexnew = inputHex.nextLine();
   System.out.print("The decimal equivilent is: " + hex2dec(Hexnew));
    }
   
    
  public static double hex2dec(String StringVal){
  double DecimalVal =0; 
    
  for (int i = 0; i<StringVal.length(); i++  ){
  char CharVal = StringVal.charAt(i);
  
  DecimalVal = hex2int(CharVal);
      
  
  };
        
    
  return ;  
    } 
   
  /*The code below iss is a method that will
  covert char into integer: meaning our hex into
  it's interger value.
  
  */
   
   public static int hex2int(char Hex ){
   
       switch(Hex){
           case 'a' | 'A':
               Hex = 10;
               break;
            case 'b' | 'B':
               Hex =11;
               break;
             case 'c' | 'C':
              Hex= 12;
               break;
            case 'd' | 'D':
               Hex =  13;
               break;
            case 'e' | 'E':
               Hex = 14;
               break;
            case 'f' | 'F':
               Hex =  15;
               break;
            default:
                Hex =Hex;
           
                       
       }
   
   return Hex; 
   }
   
    
    
    }
    

