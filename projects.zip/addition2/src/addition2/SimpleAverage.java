
package addition2;

import java.util.Scanner;

public class SimpleAverage {

    public static void main(String[] args) {
//     System.out.println("Please enter your numbers");
      String buck[] =new String[7];
      
      System.out.println(" \tDays of the week\n");
      System.out.println("Numbers\t\t" + "Days\t\t"  + "French");
      
      String week[] = {"","rrr",};
      
      
        
    }
    
}
