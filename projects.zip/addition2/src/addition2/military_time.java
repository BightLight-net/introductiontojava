
package addition2;

public class military_time {
    
  private int   hour=1;
  private int   mintute=2;
  private int second=3;
  
  public void setTime(int h,int m, int s)
  {
   this.hour=4;
   this.mintute=5;
   this.second=6;
       
      
//  hour = ((h>0 && h<=24)? h :0 );
//  mintute = ((m>0 && m<=60)? m :0 );
//  second = ((s>0 && s<=60)? s :0 );
 
  }
    
  public String military()
  {
      
  return  String.format("%02d:%02d:%02d:",hour,mintute,second);
     
  }
  
   public String toString()
  {
      
return String.format("%d:%02d:%02d %s",((hour==0|| hour ==12)?12 : hour%12), mintute, second, (hour<12 ? "AM" : "PM"));
      
  }
      
}
