
package addition2;

public class Arrayt_practice {

   
    public static void main(String[] args) {
      
        military_time useit = new military_time();
        
        System.out.println(useit.military());
        System.out.println(useit.toString());
       
        
        useit.setTime(13, 27, 5);
        System.out.println(useit.military());
        System.out.println(useit.toString());


        

}
    
}
