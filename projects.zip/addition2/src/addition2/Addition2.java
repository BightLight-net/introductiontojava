
package addition2;
import java.util.Scanner;

/**
 *
 * @author HP
 */
public class  Addition2 {
   

   
    public static void main(String[] args) {
       // too inpute = new too();
       
//      for (int i=0; i<7; i++){
//      int f=1+i;
//      int u=1+i;
//      int a=i;
//      if(3==u){
//      break;
//      }
//      System.out.println("number is" +i);
//      System.out.println("the i number is " +a);
//      }  
      
        // TODO code application logic here
        Scanner inpute = new Scanner(System.in); 
//        int number1;
//        int number2;
//        int result;
//        System.out.println("Please, enter Oyin's first salary");
//        number1= inpute.nextInt();
//        System.out.println("Please input the second salary");
//        number2= inpute.nextInt();
//        result= number1+number2;
//        System.out.println("Your income in two months is "+result);
        
        
        
        
         
    
    
    double f;
    double l;
    double r2;
  
    System.out.println("please enter C_DWR");
    double C_DWR =inpute.nextDouble();
    
    System.out.println("please enter C_FRN");
    double C_FRN =inpute.nextDouble();
    
    System.out.println("please enter C_DHD");
    double C_DHD =inpute.nextDouble();
   
    for(f=0.01;f<Double.POSITIVE_INFINITY;f=f+0.01 ){
    l=(1/(Math.sqrt(f)));
    double r= ((C_DWR/(3.7*C_DHD)) + (2.51/(C_FRN*(f))));
    r2= -2 * Math.log10(r);
    double u=f;
    if (l<r2||l==r2){
        System.out.println("it ends here ");
        break;
    }
    else if(f>500.0){
   System.exit(0);
   
    }
    
    System.out.println("the value of f is "+f);
    System.out.println("the value of l is "+l);
    System.out.println("the value of r2 is"+r2);
   
   
    }  
    System.out.println("the final  value of f is "+f+"thank you");
    }
    
}
