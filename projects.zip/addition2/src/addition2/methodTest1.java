
package addition2;
import java.util.Scanner;

public class methodTest1 {

   
    public static void main(String[] args) {
        Scanner onj = new Scanner(System.in);
        methods coni = new methods();
        
        System.out.print("Please enter your club name: ");
        String name = onj.nextLine();
        
        coni.setName(name);
        coni.display();
    }
    
}
