

package addition2;


 class methods {
     private String clubname;
     
     public void setName(String name){
    clubname = name;

}
     /*this comment can take multiple lines of code
     the codes can be on a multiple line
     it dosent matter the nubers of lunes of code*/
    public String getName(){
     return clubname;
     }
   //this method is to output on the screen  
   public void display(){
   System.out.print(getName());
   }
 }