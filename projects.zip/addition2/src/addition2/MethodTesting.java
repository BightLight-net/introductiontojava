
package addition2;

public class MethodTesting {
    private String girlname;
    
    public MethodTesting(String name)
    {
     girlname=name;
     System.out.printf("this is for contructor\n", girlname);
    };
    
    
    public void setName(String name)
    {
     girlname = name;
     System.out.printf("this is for setname\n", girlname);
    }
    
    public String getName()
    {
     System.out.printf("this is for getname\n", girlname);   
    return girlname ;
    
    
    }
    public void spellName ()
    {
        System.out.printf("The name of my first gilefriend is %s\n", getName());
    
}
}
