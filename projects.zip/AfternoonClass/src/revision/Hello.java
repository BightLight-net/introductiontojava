
package revision;


public class Hello {

    
    public static void main(String[] args) {
        
       System.out.print("Hello World");
       System.out.print("THis will display the message");      
        
    }
    
}
