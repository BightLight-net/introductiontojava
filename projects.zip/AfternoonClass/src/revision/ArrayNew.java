
package revision;


public class ArrayNew {

   
    public static void main(String[] args) {
      
        String [] Names = new String[5];
        Names[0] = "Ali";
        Names[1] = "Bello";
        Names[2] = "Adams";
        Names[3] = "Honey";
        Names[4] = "Bee";
        
        System.out.print(Names);
        System.out.print(Names.length);
        
        for(int i =0; i <Names.length; i++){
         System.out.println(Names[i]);
        }
        
        for( String n: Names ){
            System.out.println(n);
        
        }
        
        
        
        
        
        
        
        
    }
    
}
