
package ConditionStatement;


public class ifstament {

    
    public static void main(String[] args) {
        int num = 150;
        
        if(num < 50){
        System.out.println("num is less than 50");
        }else{
        System.out.println("num is greater than or equal 50");
        
        }
        
       /* if( conditiocn ){
        code statment in here
        
        }else{
        code in here
        } */
       
        
    }
    
}
