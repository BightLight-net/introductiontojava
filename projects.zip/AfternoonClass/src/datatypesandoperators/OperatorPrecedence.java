
package datatypesandoperators;

/**
 *
 * @author HP
 */
public class OperatorPrecedence {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // BODMAS   
        int fnum = 100;
        int snum = 75;
        int tnum = 25;
        
        int ans;
        
        ans = (fnum - snum) + tnum;  // 50
        
         int ans2 = fnum -( snum + tnum); // 0
         
         
         System.out.print(ans);
         System.out.print(ans2);
         
         
         
         
        
        
        
    }
    
}
