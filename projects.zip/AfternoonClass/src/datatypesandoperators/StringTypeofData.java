
package datatypesandoperators;

/**
 *
 * @kunle java
 */
public class StringTypeofData {

    public static void main(String[] args) {
    
   String greet1 = "Hello";
   String greet2 = "World";
   String name = "bob";
   
   System.out.println(greet1 + " " + greet2 + " " + 2019 +  "!");
   
       String msg = "Bob wrote "+ (2+1) + " Java programs.";
       String msg1 = name + " wrote " + 2+1 + " Java programs.";
        System.out.println(msg);
          System.out.println(msg1);


        
        
    }
    
}
