
package datatypesandoperators;

public class TernaryOperator {

    public static void main(String[] args) {
      int num1, num2;
      num1 = 25;
      
      num2 = (num1 == 10) ? 100 :200;
      System.out.println( "num2: "+num2);
      
      
      /* num1 is equal to 25 that's why
	 * the first value is assigned
	 * to the variable num2
	 */
      
       num2 = (num1 == 25) ? 100 :200;
      System.out.println( "num2: "+num2);
      
      /*BitwiseOperator*/
      
      int num3 = 11;  /* 11 = 00001011 */
     int num4 = 22;  /* 22 = 00010110 */
     int result = 0;  //00000010
                        //8421
     
     result = num3 & num4;   
     System.out.println("num3 & num4: "+result); //2
     
     result = num3 | num4;   
     System.out.println("num3 & num4: "+result); //31
      
      
      
      
        
        
    }
    
}
