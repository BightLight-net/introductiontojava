
package SimplePrograms;

import java.util.Scanner;
public class Voweldictection {

    
    public static void main(String[] args) {
        
        Scanner  scan = new Scanner(System.in);
        
        char ch;
        
        System.out.print("Enter an Alphabet: ");
        ch = scan.next().charAt(0);
        
        if(ch =='a' || ch == 'A' ||ch == 'e' || ch == 'E'
           ||ch == 'i' || ch == 'I' ||ch == 'o' || ch == 'O'
                ||ch == 'u' || ch == 'U'){
        System.out.print("This is a Vowel");
        }else{
        System.out.print("This is not Vowel");
        
        };
        
       
    }
    
}
