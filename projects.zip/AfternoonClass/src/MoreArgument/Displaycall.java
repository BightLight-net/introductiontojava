
package MoreArgument;


public class Displaycall {

    
    public static void main(String[] args) {
        MethodOverloading obj = new MethodOverloading();
        obj.disp('u', 78);
    }
    
}
