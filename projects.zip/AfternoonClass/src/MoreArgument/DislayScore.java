
package MoreArgument;


public class DislayScore {

   
    public static void main(String[] args) {
       
        Score e = new Score();
        System.out.println(e.setScore(34));
         System.out.println(e.getScore());
              
    }
    
}
