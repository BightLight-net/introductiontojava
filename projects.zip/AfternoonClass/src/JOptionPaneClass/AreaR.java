
package JOptionPaneClass;

import javax.swing.JOptionPane;
public class AreaR {
  
    public static void main(String[] args) {
        String length = JOptionPane.showInputDialog("Enter length");
    String breadth = JOptionPane.showInputDialog("Enter breadth");
    
    
    int ans = Integer.parseInt(length) * Integer.parseInt(breadth);
    JOptionPane.showMessageDialog(null, "The Area is "+ans);
    
    }
    
}
