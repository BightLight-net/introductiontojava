
package typesofvariables;


public class MyfirstApp {

   
    public static void main(String[] args) {
        
      System.out.println("Hello World");
      
      String message = "This is java programming";
      int noofemployees = 30;
      double distancekm = 10.65; 
      
      boolean OlaLoveStatus = true;
      
      String OlaAcctStatus = "true";
      String curr = "30";
      
      
        
        
    }
    
}
