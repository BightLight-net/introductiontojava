
package typesofvariables;

/**
 *
 * @kunle java
 */
public class InstanceVariable {
    
  String myInstanceVar = "This is instance variable";

    public static void main(String[] args) {
        InstanceVariable ourobject = new InstanceVariable();
        InstanceVariable ourobject1 = new InstanceVariable();
        InstanceVariable ourobject2 = new InstanceVariable();
        
        System.out.println(ourobject.myInstanceVar);
        System.out.println(ourobject1.myInstanceVar);
        System.out.println(ourobject2.myInstanceVar);
        
        ourobject1.myInstanceVar = "Changed instance variable";
        
        System.out.println(ourobject.myInstanceVar);
        System.out.println(ourobject1.myInstanceVar);
        System.out.println(ourobject2.myInstanceVar);
        
    }
    
}
