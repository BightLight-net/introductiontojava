
package Encapsulate;


public class Shirt {
    private int shirtID = 0; 	
    private String description = "-description required-"; 
    private char colorCode = 'U'; 
    private double price = 0.0;
    
    public char getColorCode(){
    return colorCode;
    }
    public void setColorCode(char newCode){
        colorCode = newCode;
    }
    
    public int getShirtID(){
    return colorCode;
    }
    public void setShirtID(int newshirt){
        shirtID= newshirt;
    }
    
    
    
    
    
    
}
