
package Encapsulate;


public class EncapTest {

    
    public static void main(String[] args) {
        Info obj = new Info();
        
        obj.setEmpName("Trump");
        obj.setEmpAge(54);
        obj.setEmpSSN(112233);
        
        
         System.out.println("Employee Name: " + obj.getEmpName());
         System.out.println("Employee SSN: " + obj.getEmpSSN());
         System.out.println("Employee Age: " + obj.getEmpAge());
        
        
        
    }
    
}
