
package Projects;

public class PlayingwithArray {

   
    public static void main(String[] args) {
        
        
        
        
     
    }
    
}
