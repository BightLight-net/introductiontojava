
package MethodRemix;


public class ShirtCalling {

   
    public static void main(String[] args) {
        Cloth shirt01 = new Cloth("Sailor", 'B', 30);
        Cloth shirt02 = new Cloth("Sweatshirt", 'G', 25);
        Cloth shirt03 = new Cloth("Skull Tee", 'B', 15);
        Cloth shirt04 = new Cloth("Tropical", 'R', 20);
        
//        shirt01.description = "Sailor";
//        shirt01.colorCode = 'B';
//        shirt01.price = 30;
//
//        
//        shirt02.description = "Sweatshirt";
//        shirt02.colorCode = 'G';
//        shirt02.price = 25;
//        
//        shirt03.description = "Skull Tee";
//        shirt03.colorCode = 'B';
//        shirt03.price = 15;
//
//         shirt04.description = "Tropical";
//        shirt04.colorCode = 'R';
//        shirt04.price = 20;
        
        
//        shirt01.setField("Sailor", 'B', 30);
//        shirt02.setField("Sweatshirt", 'G', 25);
//        shirt02.setField("Skull Tee", 'B', 15);
        
        
        
    }
    
}
