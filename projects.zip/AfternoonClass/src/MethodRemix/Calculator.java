
package MethodRemix;

public class Calculator {
    
    public void calculate(int x, double y){
    System.out.println(x/y);
    }
    
    
}
