
package MethodRemix;

public class Argument {

    public static void main(String[] args) {
        Calculator calc = new Calculator();
        double denominator = 2.0;
        
        calc.calculate(3, denominator);
    }
    
}
