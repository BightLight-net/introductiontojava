
package Arrays;

public class WorkingWithArray {

    public static void main(String[] args) {
     
        String[] staff = new String[4];
        
         staff[0] = "Uthman";
         staff[2] = "Honey";
         staff[3] = "Tony";
         
         System.out.println(staff[2]);
         System.out.println(staff.length);
         
         System.out.println("New managers are " + staff[2] +" and " + staff[3]);
         
        
        
        
    }
    
}
