
package Polymorphism;

/**
 *
 * @author HP
 */
public class Dog extends Animal {
     //@Override 
    public void sound(){
       
    System.out.println("barking"); 
    }
    
    public static void main(String[] args) {
      Dog obj = new Dog();
      obj.sound();
        
    }
    
}

 class Animal{
public void sound(){
    System.out.println("Animal is making a sound"); 

}
     
}