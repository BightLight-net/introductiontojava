
package Polymorphism;


public class AceessBank  extends Fidelity{

    @Override
    void loanRate(){
     System.out.println("14%");
    }
    
    public static void main(String[] args) {
        CentralBank c1,c2,c3;
        
        c1 = new CentralBank();
        
        c1= new CentralBank();
        c2= new Fidelity();
        c3 = new AceessBank();
        c1.loanRate();
        c2.loanRate();
        c3.loanRate();
        
        
        
    }
    
}

class Fidelity extends  CentralBank{

    
    void loanRate(){
    System.out.println("24%");
    }
    
}

class CentralBank{
void loanRate(){
  System.out.println("34%");
}
}
