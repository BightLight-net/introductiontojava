
package ExploringClassAndObject;


public class Customer {
    
    public String name ;
    public int custID;
    public String address;
    public int orderNum;
    public int age;
    
    Customer(String newName,String newAddress,int newAge){
    
        name =  newName;
        age = newAge;
        address = newAddress;
    
    }
    
    
    public void displayCustomer(){
        //name =newName;
    
        System.out.println(" Customer: "+name);
    }
    
    public  void displayAge(){
         
      // int addup = 10;
        //age = newAge + addup;
       
        //return age;
    System.out.println(" Customer: "+age);
    }
    
    public void displayAddress(){
        //address = newAddress;
    System.out.println(" Customer: "+address);  
    
}
}