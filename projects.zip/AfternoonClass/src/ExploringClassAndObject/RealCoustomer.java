
package ExploringClassAndObject;


public class RealCoustomer {

    
    public static void main(String[] args) {
      Customer uthman  = new Customer("Uthman","Goverment house",87);
      Customer Honey  = new Customer("Honey","Goverment house",50);
      
      
      
      
     uthman = Honey;
      
      
      uthman.displayCustomer();
      uthman.displayAddress();
      uthman.displayAge();
      
      Honey.displayCustomer();
      Honey.displayAddress();
      Honey.displayAge();
      
      
     // uthman.name = "Uthman";
      //uthman.age = 89;
     // uthman.address = "Goverment house";
      
      
      //Honey.name ="Honey" ;
     // Honey.age = 180;
     // Honey.address = "White house";
      
      
//      uthman.displayCustomer("Uthman");
//      int Age = uthman.displayAge(50);
//      System.out.print(Age);
//      uthman.displayAddress("Goverment house");
//      
//
//      Honey.displayCustomer("Honey");
//      Honey.displayAge(100);
//      Honey.displayAddress("White house");
//      
      
     
      
         
      
    }
    
}
