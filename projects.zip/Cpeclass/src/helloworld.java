
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JButton;

import java.util.Scanner;
    public class helloworld extends JFrame{
	public static void main(String[] args){
            JFrame newframe = new JFrame();
            JButton obj = new JButton();
            
            obj.createImage(null);
            

Scanner user_input = new Scanner(System.in);

String firstname;
System.out.print("Please enter your first name\n");
firstname=user_input.next();

String secondname;
System.out.print("Please enter your second name\n");
secondname=user_input.next();

String answer= firstname+"  "+secondname;
System.out.println("Your name is " +answer);





	}		
}
    

