/*
 One of the strengths of Java is the huge libraries of code available to you.
All you need to do is to reference which library you want to use, and then call a
method into action.
One really useful class that handles input from a user is called the Scanner class
 The Scanner class can be found in the java.util library

 */
package acceptinginput;

import java.util.Scanner;

public class InputScanner {

    public static void main(String[] args) {
        
        Scanner user_input = new Scanner(System.in);
        
        String dept;
        System.out.println("Please enter the name of your department ");
        dept = user_input.next();
        
         Scanner.
        System.out.println("Please enter your age ");
        String age = user_input.next();
        
         System.out.println("your department and age are " + dept +" "+ "and" + " " + age + " "+"respectively" );
        
        
        
        
        
    }
    
}
