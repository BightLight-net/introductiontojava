
package innerclass;

/**
 *
 * @kunle java

 */
public class InnerClassConcept {
    
    public void method1(){
        class InnerClass{
            public void display(){
            
            System.out.println("All is well"); // the statment to be displayed
            }
        
        
        
        }
        InnerClass con = new InnerClass();
        con.display();  // prints out method display inside class InnerClass 
    
    
    }

    public static void main(String[] args) {
        InnerClassConcept link = new InnerClassConcept();   // object of our main class
        link.method1();   //print the statements in method method1
        
               
    }
    
}
