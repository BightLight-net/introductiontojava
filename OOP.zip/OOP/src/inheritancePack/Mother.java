
package inheritancePack;

/**
 *
 * @kunle java
 */
public class Mother extends Grandma {
    public String name =" Tobi Java";
    
    public void character(){
    System.out.println("Calm and Intelligent");
    }
    
    
}
