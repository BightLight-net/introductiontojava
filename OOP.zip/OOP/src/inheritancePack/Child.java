
package inheritancePack;

/**
 *
 * @kunle java
 */
public class Child extends Parents{
    
    public void money(){
        System.out.println("I have five million naira inmy account");
    }
    
    public static void main(String[] args) {
        Child  tobi = new Child();
        System.out.println("Grandpa died at aage" +  tobi.age);
        tobi.money();
        tobi.house();
        
        Parents pt = new Parents();
        System.out.println("your age is"+pt.age);
        pt.money();
        
        
    }
    
}

class Parents extends Granpa{
public int age =78;

public void money(){
System.out.println("I have Two million naira in my account");
}

}

class Granpa{
public void house(){
System.out.println("I have two houses");


}}



