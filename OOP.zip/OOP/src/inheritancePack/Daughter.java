
package inheritancePack;

/**
 *
 * @kunle java
 */
public class Daughter extends Mother {
    public static void main(String[] args) {
        // TODO code application logic here
        
        Daughter d = new Daughter();
        d.character();
        System.out.println(d.name);
        System.out.println("I inherited" + d.worth()+ "from my Grandma");
    }
    
    
}
