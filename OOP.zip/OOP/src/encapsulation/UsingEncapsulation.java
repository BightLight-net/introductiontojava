
package encapsulation;

/**
 *
 * @Kunle Java
 */
class EmployeeCount{
    private int numOfEmployees = 0;
    public void setNoOfEMployees (int count){
        numOfEmployees = count;    
    }
    public double getNoOfEmployees(){
        return numOfEmployees;
      
    }
}


public class UsingEncapsulation {   
    public static void main(String[] args) {
        EmployeeCount obj = new EmployeeCount();
        obj.setNoOfEMployees(5613);
        System.out.println("No Of Employees: "+(int)obj.getNoOfEmployees());
        
    }
    
}
