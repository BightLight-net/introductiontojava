
package encapsulation;

import java.util.ArrayList;

import java.util.Scanner;
class EncapTest{
    private int ssn;
    private String empName;
    private int empAge;
    
    //Getter and Setter methods
    public int getEmpSSN(){
        return ssn;
    }
    public String getName(){
        return empName;
    }
    public int getEmpAge(){
        return empAge;
    }
    public void setEmpAge(int newValue){
        empAge = newValue;
    }
    public void setEmpName(String newValue){
        empName = newValue;
    }
    public void setEmpSSN(int newValue){
        ssn = newValue;
    }
}
public class EncapsulationDemo {
    
        EncapTest Toyese = new EncapTest();
        EncapTest Chijioke = new EncapTest();
    
//     public  void passobject(  EncapTest k  ){
//        Scanner scan = new Scanner(System.in);
//        
//        System.out.println("Enter the Name: ");
//        k.setEmpName(scan.next());
//        
//        System.out.println("Enter the Age: ");
//        k.setEmpAge(scan.nextInt());
//        
//        System.out.println("Enter the SSN: ");
//        k.setEmpSSN(scan.nextInt());
        //}

    
    public static void main(String[] args) {
        
       
       ArrayList arr = new ArrayList();  
         EncapTest Raph = new EncapTest();
       // int count = 0;
         
         
         Scanner scan = new Scanner(System.in);
       while (true){
       System.out.println("Enter the Name: ");
        Raph.setEmpName(scan.next());
       
        System.out.println("Enter the Age: ");
        Raph.setEmpAge(scan.nextInt());
        
        System.out.println("Enter the SSN: ");
        Raph.setEmpSSN(scan.nextInt());
       }
         
               
                
       
        
        // arr.add(Raph.getName());
       // System.out.println("Employee Name "+ arr.add(Raph.getEmpAge()));
       // System.out.println("Employee Name "+ arr.add(Raph.getEmpSSN()));
       
    }
    
}
