
package oop;


public class Oop {

    
    public static void main(String[] args) {
        
    }
    
}
