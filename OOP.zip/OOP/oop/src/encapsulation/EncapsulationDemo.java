
package encapsulation;
import java.util.Scanner;
class EncapTest{
    private int ssn;
    private String empName;
    private int empAge;
    
    //Getter and Setter methods
    public int getEmpSSN(){
        return ssn;
    }
    public String getName(){
        return empName;
    }
    public int getEmpAge(){
        return empAge;
    }
    public void setEmpAge(int newValue){
        empAge = newValue;
    }
    public void setEmpName(String newValue){
        empName = newValue;
    }
    public void setEmpSSN(int newValue){
        ssn = newValue;
    }
}
public class EncapsulationDemo {

    
    public static void main(String[] args) {
        EncapTest obj = new EncapTest();
        Scanner scan = new Scanner(System.in);
        
        System.out.println("Enter the Name: ");
        obj.setEmpName(scan.next());
        
        System.out.println("Enter the Age: ");
        obj.setEmpAge(scan.nextInt());
        
        System.out.println("Enter the SSN: ");
        obj.setEmpSSN(scan.nextInt());
        
        System.out.println("Employee Name "+ obj.getName());
        System.out.println("Employee Name "+ obj.getEmpAge());
        System.out.println("Employee Name "+ obj.getEmpSSN());
        
    }
    
}
